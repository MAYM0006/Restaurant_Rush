# CT2003 Restaurant Rush - Multi-Stage Implementation

This directory contains standalone, individually executable implementations for all three stages of the CT2003 Restaurant Rush assignment:

- **Stage1/**: Base game mechanics (Regular Customers, Waiter, Chef, Cashier, 2 Tables).
- **Stage2/**: Intermediate mechanics (Adds VIP and Critic Customer subclasses).
- **Stage3/**: Complete mechanics (Adds Host extra-seating staff, Happy Hour, ComboMeal domain objects, and atomic turn validation).

## How to Run Any Stage

Navigate to the respective stage folder (`Stage1`, `Stage2`, or `Stage3`):

### Windows (`cmd`):
```cmd
run.bat
```

### Linux / Mac (`terminal`):
```bash
chmod +x run.sh
./run.sh
```

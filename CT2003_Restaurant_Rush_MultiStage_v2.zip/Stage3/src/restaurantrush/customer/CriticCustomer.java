package restaurantrush.customer;

import restaurantrush.domain.MenuItem;
import restaurantrush.domain.Order;

public class CriticCustomer extends Customer {
    public CriticCustomer(String id) { super(id); }
    @Override public int getDecayRate() { return 12; }
    @Override public double getDiscountRate() { return 0.0; }
    @Override public Order chooseFood() { return new Order(MenuItem.SALAD); }
}

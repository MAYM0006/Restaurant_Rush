package restaurantrush.customer;

import restaurantrush.domain.MenuItem;
import restaurantrush.domain.Order;

public class VIPCustomer extends Customer {
    public VIPCustomer(String id) { super(id); }
    @Override public int getDecayRate() { return 5; }
    @Override public double getDiscountRate() { return 0.10; }
    @Override public Order chooseFood() { return new Order(MenuItem.BURGER); }
}

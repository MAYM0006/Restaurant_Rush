package restaurantrush.domain;

public class Order {
    private final MenuItem menuItem;
    private int unitsDone;
    private boolean happyHourDiscountApplied;

    public Order(MenuItem menuItem) {
        this.menuItem = menuItem;
        this.unitsDone = 0;
        this.happyHourDiscountApplied = false;
    }

    public MenuItem getMenuItem() { return menuItem; }
    public int getUnitsDone() { return unitsDone; }
    public boolean isHappyHourDiscountApplied() { return happyHourDiscountApplied; }
    public void setHappyHourDiscountApplied(boolean applied) { this.happyHourDiscountApplied = applied; }

    public void advancePrep() {
        if (!isReady()) {
            this.unitsDone++;
        }
    }

    public boolean isReady() {
        return unitsDone >= menuItem.getRequiredPrepUnits();
    }
}

# CT2003 Restaurant Rush - Refactored Codebase (Fixed UI & Imports)

This zip contains the fixed Stage 3 codebase.
- Customer 1 now appears in the queue on Turn 1 before manager inputs.
- All static inner class imports in `RestaurantRushCLI.java` are properly resolved.

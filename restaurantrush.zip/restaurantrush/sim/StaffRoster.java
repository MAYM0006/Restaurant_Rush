package restaurantrush.sim;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;

/**
 * The staff list. View each person and role, add a guard, chef, waiter, or
 * cashier, or remove someone by name. Reed, June, Milo, and Nia start the night.
 * The last person in a role can be removed, and that role's work stops.
 */
public final class StaffRoster {
    public static final List<StaffMember> DEFAULTS = List.of(
            new StaffMember("reed", "Reed", StaffRole.GUARD),
            new StaffMember("june", "June", StaffRole.CHEF),
            new StaffMember("milo", "Milo", StaffRole.WAITER),
            new StaffMember("nia", "Nia", StaffRole.CASHIER));

    private static final Pattern LETTER_OR_NUMBER = Pattern.compile("[\\p{L}\\p{N}]");

    private final List<StaffMember> staff;

    private StaffRoster(List<StaffMember> staff) {
        this.staff = staff;
    }

    public static StaffRoster opening() {
        return new StaffRoster(defaults());
    }

    public List<StaffMember> members() {
        return copy(staff);
    }

    public List<String> view() {
        return directory(staff);
    }

    public static List<StaffMember> defaults() {
        return copy(DEFAULTS);
    }

    public static List<StaffMember> copy(List<StaffMember> staff) {
        return new ArrayList<>(staff);
    }

    public static boolean has(List<StaffMember> staff, StaffRole role) {
        for (StaffMember person : staff) {
            if (person.role == role) {
                return true;
            }
        }
        return false;
    }

    public static List<String> missingLines(List<StaffMember> staff) {
        List<String> lines = new ArrayList<>();
        for (StaffRole role : StaffRole.values()) {
            if (!has(staff, role)) {
                lines.add(role.missing);
            }
        }
        return lines;
    }

    public static List<String> directory(List<StaffMember> staff) {
        if (staff.isEmpty()) {
            return List.of("Nobody is on staff.");
        }
        List<String> lines = new ArrayList<>();
        for (StaffMember person : staff) {
            lines.add(line(person));
        }
        return lines;
    }

    public static String line(StaffMember person) {
        return person.name + ", " + person.role.title + ": " + person.role.blurb;
    }

    public static NameResult normalize(List<StaffMember> staff, String raw) {
        String name = collapse(raw);
        if (name.isEmpty() || !LETTER_OR_NUMBER.matcher(name).find()) {
            return NameResult.error("Enter a name.");
        }
        if (name.length() > 24) {
            return NameResult.error("Keep the name to 24 characters.");
        }
        for (StaffMember person : staff) {
            if (person.name.toLowerCase(Locale.ROOT).equals(name.toLowerCase(Locale.ROOT))) {
                return NameResult.error("That person is already on staff.");
            }
        }
        return NameResult.ok(name);
    }

    public static StaffChange add(List<StaffMember> staff, String name, String roleText) {
        NameResult named = normalize(staff, name);
        if (!named.ok) {
            return StaffChange.error(named.error);
        }
        StaffRole role = StaffRole.parse(roleText);
        if (role == null) {
            return StaffChange.error("Role is one of guard, chef, waiter, cashier.");
        }
        List<StaffMember> next = copy(staff);
        StaffMember person = new StaffMember(staffId(named.text, staff), named.text, role);
        next.add(person);
        return StaffChange.changed(next, person);
    }

    public static StaffChange remove(List<StaffMember> staff, String rawName) {
        String wanted = collapse(rawName).toLowerCase(Locale.ROOT);
        if (wanted.isEmpty()) {
            return StaffChange.error("Enter a name.");
        }
        StaffMember removed = null;
        for (StaffMember person : staff) {
            if (person.name.toLowerCase(Locale.ROOT).equals(wanted)) {
                removed = person;
                break;
            }
        }
        if (removed == null) {
            String shown = rawName == null ? "" : rawName.trim();
            return StaffChange.error("No staff member called " + shown + ".");
        }
        List<StaffMember> next = new ArrayList<>();
        for (StaffMember person : staff) {
            if (!person.id.equals(removed.id)) {
                next.add(person);
            }
        }
        return StaffChange.changed(next, removed);
    }

    public StaffChange addMember(String name, String roleText) {
        StaffChange change = add(staff, name, roleText);
        if (change.ok) {
            staff.clear();
            staff.addAll(change.staff);
        }
        return change;
    }

    public StaffChange removeMember(String name) {
        StaffChange change = remove(staff, name);
        if (change.ok) {
            staff.clear();
            staff.addAll(change.staff);
        }
        return change;
    }

    private static String collapse(String raw) {
        if (raw == null) {
            return "";
        }
        return raw.trim().replaceAll("\\s+", " ");
    }

    private static String staffId(String name, List<StaffMember> staff) {
        String base = name.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]+", "-").replaceAll("^-|-$", "");
        if (base.isEmpty()) {
            base = "staff";
        }
        String id = base;
        int suffix = 2;
        while (taken(staff, id)) {
            id = base + "-" + suffix;
            suffix += 1;
        }
        return id;
    }

    private static boolean taken(List<StaffMember> staff, String id) {
        for (StaffMember person : staff) {
            if (person.id.equals(id)) {
                return true;
            }
        }
        return false;
    }

    public static final class NameResult {
        public final boolean ok;
        public final String text;
        public final String error;

        private NameResult(boolean ok, String text, String error) {
            this.ok = ok;
            this.text = text;
            this.error = error;
        }

        static NameResult ok(String text) {
            return new NameResult(true, text, null);
        }

        static NameResult error(String error) {
            return new NameResult(false, null, error);
        }
    }

    public static final class StaffChange {
        public final boolean ok;
        public final List<StaffMember> staff;
        public final String error;
        public final StaffMember person;

        private StaffChange(boolean ok, List<StaffMember> staff, String error, StaffMember person) {
            this.ok = ok;
            this.staff = staff;
            this.error = error;
            this.person = person;
        }

        static StaffChange error(String error) {
            return new StaffChange(false, null, error, null);
        }

        static StaffChange changed(List<StaffMember> staff, StaffMember person) {
            return new StaffChange(true, staff, null, person);
        }
    }
}

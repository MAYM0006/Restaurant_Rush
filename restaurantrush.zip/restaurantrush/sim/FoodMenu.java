package restaurantrush.sim;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;
import restaurantrush.entity.Money;

/**
 * The food menu. View the dishes, add one (name, price in dollars, prep units
 * of at least 1 with no upper cap), or delete one by name. The last dish stays.
 */
public final class FoodMenu {
    public static final List<Dish> DEFAULTS = List.of(
            new Dish("salad", "Salad", 900, 1),
            new Dish("burger", "Burger", 1500, 1),
            new Dish("pasta", "Pasta", 1800, 2));

    private static final Pattern PRICE = Pattern.compile("\\d+(\\.\\d{1,2})?");
    private static final Pattern PREP = Pattern.compile("\\d+");
    private static final Pattern LETTER_OR_NUMBER = Pattern.compile("[\\p{L}\\p{N}]");
    private static final BigDecimal MAX_DOLLARS = new BigDecimal("999");

    private final List<Dish> dishes;

    private FoodMenu(List<Dish> dishes) {
        this.dishes = dishes;
    }

    public static FoodMenu opening() {
        return new FoodMenu(defaults());
    }

    public List<Dish> dishes() {
        return copy(dishes);
    }

    public List<String> view() {
        return lines(dishes);
    }

    public static List<Dish> defaults() {
        return copy(DEFAULTS);
    }

    public static List<Dish> copy(List<Dish> menu) {
        return new ArrayList<>(menu);
    }

    public static List<String> lines(List<Dish> menu) {
        if (menu.isEmpty()) {
            return List.of("The menu is empty.");
        }
        List<String> lines = new ArrayList<>();
        for (Dish dish : menu) {
            lines.add(dish.name + "  " + Money.dollars(dish.priceCents) + "  " + prepLabel(dish.prep));
        }
        return lines;
    }

    public static String prepLabel(long prep) {
        return prep == 1 ? "1 prep unit" : prep + " prep units";
    }

    /** Dollars such as 14 or $9.50. Above zero and at most 999. Returns cents. */
    public static Integer parsePriceDollars(String text) {
        if (text == null) {
            return null;
        }
        String trimmed = text.trim().replaceFirst("^\\$", "");
        if (!PRICE.matcher(trimmed).matches()) {
            return null;
        }
        BigDecimal amount = new BigDecimal(trimmed);
        if (amount.compareTo(BigDecimal.ZERO) <= 0 || amount.compareTo(MAX_DOLLARS) > 0) {
            return null;
        }
        int cents = amount.movePointRight(2).setScale(0, RoundingMode.HALF_UP).intValueExact();
        return cents > 0 ? cents : null;
    }

    /** Any whole number of prep units, at least 1. There is no upper cap. */
    public static Long parsePrep(String text) {
        if (text == null) {
            return null;
        }
        String trimmed = text.trim();
        if (!PREP.matcher(trimmed).matches()) {
            return null;
        }
        try {
            long prep = Long.parseLong(trimmed);
            return prep >= 1 ? prep : null;
        } catch (NumberFormatException ex) {
            return Long.MAX_VALUE;
        }
    }

    public static NameResult normalize(List<Dish> menu, String raw) {
        String name = collapse(raw);
        if (name.isEmpty() || !LETTER_OR_NUMBER.matcher(name).find()) {
            return NameResult.error("Enter a dish name.");
        }
        if (name.length() > 24) {
            return NameResult.error("Keep the dish name to 24 characters.");
        }
        for (Dish dish : menu) {
            if (dish.name.toLowerCase(Locale.ROOT).equals(name.toLowerCase(Locale.ROOT))) {
                return NameResult.error("That dish is already on the menu.");
            }
        }
        return NameResult.ok(name);
    }

    public static MenuChange add(List<Dish> menu, String name, String priceDollars, String prepText) {
        NameResult named = normalize(menu, name);
        if (!named.ok) {
            return MenuChange.error(named.error);
        }
        Integer priceCents = parsePriceDollars(priceDollars);
        if (priceCents == null) {
            return MenuChange.error("Enter a price in dollars, above zero.");
        }
        Long prep = parsePrep(prepText);
        if (prep == null) {
            return MenuChange.error("Prep units must be a whole number, at least 1.");
        }
        List<Dish> next = copy(menu);
        Dish dish = new Dish(dishId(named.text, menu), named.text, priceCents, prep);
        next.add(dish);
        return MenuChange.added(next, dish);
    }

    public static MenuChange remove(List<Dish> menu, String rawName) {
        String wanted = collapse(rawName).toLowerCase(Locale.ROOT);
        if (wanted.isEmpty()) {
            return MenuChange.error("Enter a dish name.");
        }
        Dish removed = null;
        for (Dish dish : menu) {
            if (dish.name.toLowerCase(Locale.ROOT).equals(wanted)) {
                removed = dish;
                break;
            }
        }
        if (removed == null) {
            String shown = rawName == null ? "" : rawName.trim();
            return MenuChange.error("No dish called " + shown + ".");
        }
        if (menu.size() <= 1) {
            return MenuChange.error("The menu needs at least one dish.");
        }
        List<Dish> next = new ArrayList<>();
        for (Dish dish : menu) {
            if (!dish.id.equals(removed.id)) {
                next.add(dish);
            }
        }
        return MenuChange.removed(next, removed);
    }

    public MenuChange addDish(String name, String priceDollars, String prepText) {
        MenuChange change = add(dishes, name, priceDollars, prepText);
        if (change.ok) {
            dishes.clear();
            dishes.addAll(change.menu);
        }
        return change;
    }

    public MenuChange deleteDish(String name) {
        MenuChange change = remove(dishes, name);
        if (change.ok) {
            dishes.clear();
            dishes.addAll(change.menu);
        }
        return change;
    }

    private static String collapse(String raw) {
        if (raw == null) {
            return "";
        }
        return raw.trim().replaceAll("\\s+", " ");
    }

    private static String dishId(String name, List<Dish> menu) {
        String base = name.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]+", "-").replaceAll("^-|-$", "");
        if (base.isEmpty()) {
            base = "dish";
        }
        String id = base;
        int suffix = 2;
        while (taken(menu, id)) {
            id = base + "-" + suffix;
            suffix += 1;
        }
        return id;
    }

    private static boolean taken(List<Dish> menu, String id) {
        for (Dish dish : menu) {
            if (dish.id.equals(id)) {
                return true;
            }
        }
        return false;
    }

    public static final class NameResult {
        public final boolean ok;
        public final String text;
        public final String error;

        private NameResult(boolean ok, String text, String error) {
            this.ok = ok;
            this.text = text;
            this.error = error;
        }

        static NameResult ok(String text) {
            return new NameResult(true, text, null);
        }

        static NameResult error(String error) {
            return new NameResult(false, null, error);
        }
    }

    public static final class MenuChange {
        public final boolean ok;
        public final List<Dish> menu;
        public final String error;
        public final Dish dish;

        private MenuChange(boolean ok, List<Dish> menu, String error, Dish dish) {
            this.ok = ok;
            this.menu = menu;
            this.error = error;
            this.dish = dish;
        }

        static MenuChange error(String error) {
            return new MenuChange(false, null, error, null);
        }

        static MenuChange added(List<Dish> menu, Dish dish) {
            return new MenuChange(true, menu, null, dish);
        }

        static MenuChange removed(List<Dish> menu, Dish dish) {
            return new MenuChange(true, menu, null, dish);
        }
    }
}

package restaurantrush.sim;

import java.util.List;

/**
 * Cooks every ordered plate. A higher prep number only makes that plate take
 * longer. If no chef is on duty, plates do not cook.
 */
public final class Chef {
    public static final long MILLIS_PER_PREP = 2400;

    private Chef() {
    }

    public static boolean onDuty(List<StaffMember> staff) {
        return StaffRoster.has(staff, StaffRole.CHEF);
    }

    public static long timeNeeded(long prep) {
        long units = Math.max(1, prep);
        if (units > Long.MAX_VALUE / MILLIS_PER_PREP) {
            return Long.MAX_VALUE;
        }
        return units * MILLIS_PER_PREP;
    }

    public static void begin(Guest guest, long prep, boolean chefOnDuty) {
        guest.prep = prep;
        guest.cookMs = 0;
        guest.cookNeeded = timeNeeded(prep);
        if (!chefOnDuty) {
            guest.blocked = StaffRole.CHEF;
        }
    }

    public static String kitchenLine(boolean chefOnDuty) {
        return chefOnDuty ? "The kitchen starts cooking." : StaffRole.CHEF.missing;
    }

    /**
     * How long this turn still counts as waiting. Service stops the drop just
     * before the plate is ready. With no waiter the plate keeps waiting.
     */
    public static long waitingUntil(long previousElapsed, long elapsed, long cookMs, long cookNeeded,
            boolean waiterOnDuty, long shiftEnd) {
        if (!waiterOnDuty) {
            return Math.min(elapsed, shiftEnd);
        }
        long serveAt = previousElapsed + Math.max(0, cookNeeded - cookMs);
        long justBeforeReady = Math.max(previousElapsed, serveAt - 1);
        return Math.min(elapsed, Math.min(justBeforeReady, shiftEnd));
    }

    /** Adds cook time. Without a chef the plate does not move. */
    public static Batch cook(Guest guest, long deltaMs, boolean chefOnDuty) {
        if (!chefOnDuty) {
            return new Batch(Pace.NO_CHEF, 0);
        }
        guest.cookMs += deltaMs;
        if (guest.cookMs < guest.cookNeeded) {
            return new Batch(Pace.COOKING, 0);
        }
        long overshoot = guest.cookMs - guest.cookNeeded;
        guest.cookMs = guest.cookNeeded;
        return new Batch(Pace.READY, overshoot);
    }

    public enum Pace {
        NO_CHEF, COOKING, READY
    }

    public static final class Batch {
        public final Pace pace;
        public final long overshootMs;

        public Batch(Pace pace, long overshootMs) {
            this.pace = pace;
            this.overshootMs = overshootMs;
        }
    }
}

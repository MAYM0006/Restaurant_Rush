package restaurantrush.sim;

import java.util.ArrayList;
import java.util.List;

/**
 * The door. Happy Hour is allowed only when everyone in the party is 18 or
 * older and they want Happy Hour. Table 2 with someone under 18 names them,
 * says they are below 18, and does not seat the party. No guard closes Happy
 * Hour seating.
 */
public final class Guard {
    public static final int MIN_AGE = 18;
    public static final String IDLE = "Guard on the door. Happy Hour is for guests 18 or older who want it.";

    private Guard() {
    }

    public static boolean onDuty(List<StaffMember> staff) {
        return StaffRoster.has(staff, StaffRole.GUARD);
    }

    public static Decision review(List<Guest> members) {
        if (members.isEmpty()) {
            return new Decision(false, false, null);
        }
        boolean wantsHappyHour = true;
        for (Guest member : members) {
            if (!member.wantsHappyHour) {
                wantsHappyHour = false;
                break;
            }
        }
        if (!wantsHappyHour) {
            return new Decision(false, true, null);
        }
        List<Guest> minors = minors(members);
        if (!minors.isEmpty()) {
            List<String> why = new ArrayList<>();
            for (Guest member : minors) {
                why.add(member.name + " is " + member.age);
            }
            String refusal = "Guard refuses Happy Hour for " + Guests.names(members) + ". " + String.join(" and ", why)
                    + ", under 18. They can still sit at either table without Happy Hour.";
            return new Decision(false, true, refusal);
        }
        return new Decision(true, false, null);
    }

    /**
     * Choice 2, or any Happy Hour seat, while someone is under 18. Null when
     * the whole party is old enough. The caller must leave the party standing.
     */
    public static String belowEighteen(List<Guest> party) {
        List<Guest> minors = minors(party);
        if (minors.isEmpty()) {
            return null;
        }
        if (minors.size() == 1) {
            return minors.get(0).name + " is below 18, so no Happy Hour.";
        }
        List<String> names = new ArrayList<>();
        for (Guest minor : minors) {
            names.add(minor.name);
        }
        return String.join(" and ", names) + " are below 18, so no Happy Hour.";
    }

    public static String approval(List<Guest> members) {
        if (members.size() == 1) {
            Guest member = members.get(0);
            return "Guard checks " + member.name + ". Age " + member.age + ", wants Happy Hour. Table 2 is 20% off.";
        }
        List<String> ages = new ArrayList<>();
        for (Guest member : members) {
            ages.add(member.name + ", age " + member.age);
        }
        String list = ages.size() == 2
                ? ages.get(0) + " and " + ages.get(1)
                : String.join(", ", ages.subList(0, ages.size() - 1)) + ", and " + ages.get(ages.size() - 1);
        return "Guard checks " + list + ". They want Happy Hour, and everyone is 18 or older. Table 2 is 20% off.";
    }

    private static List<Guest> minors(List<Guest> members) {
        List<Guest> minors = new ArrayList<>();
        for (Guest member : members) {
            if (member.age < MIN_AGE) {
                minors.add(member);
            }
        }
        return minors;
    }

    public static final class Decision {
        public final boolean happyHour;
        public final boolean regular;
        public final String refusal;

        public Decision(boolean happyHour, boolean regular, String refusal) {
            this.happyHour = happyHour;
            this.regular = regular;
            this.refusal = refusal;
        }
    }
}

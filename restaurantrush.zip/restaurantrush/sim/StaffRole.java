package restaurantrush.sim;

import java.util.Locale;

public enum StaffRole {
    GUARD("Guard", "watches the door and checks Happy Hour ages.", "No guard on duty. Happy Hour is closed."),
    CHEF("Chef", "cooks incoming orders in preparation units.", "No chef on duty. Plates do not cook."),
    WAITER("Waiter", "seats guests, takes orders, and serves ready plates.", "No waiter on duty. Service stops."),
    CASHIER("Cashier", "collects bills and tips when guests finish eating.", "No cashier on duty. Nobody can pay.");

    public final String title;
    public final String blurb;
    public final String missing;

    StaffRole(String title, String blurb, String missing) {
        this.title = title;
        this.blurb = blurb;
        this.missing = missing;
    }

    public static StaffRole parse(String text) {
        if (text == null) return null;
        String lower = text.trim().toLowerCase(Locale.ROOT);
        return switch (lower) {
            case "guard" -> GUARD;
            case "chef" -> CHEF;
            case "waiter" -> WAITER;
            case "cashier" -> CASHIER;
            default -> null;
        };
    }
}
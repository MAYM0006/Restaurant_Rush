package restaurantrush.sim;

import java.util.ArrayList;
import java.util.List;
import java.util.function.DoubleSupplier;

/**
 * One 18-turn shift. The guard, chef, waiter, cashier, tables, menu, and guest
 * list each keep their own rules. This class runs the clock and asks them to
 * do their jobs. Money is cents.
 */
public final class Night {
    public enum Service {
        SERVICE, OVER
    }

    public static final long COOK_MS_PER_UNIT = Chef.MILLIS_PER_PREP;
    public static final long EAT_MS = Guests.EAT_MS;
    public static final int TIP_PERCENT = Cashier.TIP_PERCENT;
    public static final int TIP_ABOVE = Cashier.TIP_ABOVE;
    public static final int TURN_DECAY = Guests.TURN_DECAY;
    public static final int SEATS_PER_TABLE = Tables.SEATS;
    public static final int HAPPY_HOUR_TABLE = Tables.HAPPY_HOUR;
    public static final int TABLE_COUNT = Tables.COUNT;
    public static final int HAPPY_HOUR_MIN_AGE = Guard.MIN_AGE;
    public static final int HAPPY_HOUR_KEEP = Tables.HAPPY_HOUR_KEEP;
    public static final String GUARD_IDLE = Guard.IDLE;
    public static final int TURN_COUNT = Guests.TURN_COUNT;
    public static final long TURN_MS = Guests.TURN_MS;
    public static final long SHIFT_LENGTH_MS = Guests.SHIFT_LENGTH_MS;
    public static final int WIN_PAID = Guests.WIN_PAID;
    public static final int WIN_CENTS = Guests.WIN_CENTS;

    public long elapsed;
    public List<Dish> menu = new ArrayList<>();
    public List<StaffMember> staff = new ArrayList<>();
    public List<Guest> guests = new ArrayList<>();
    public String[][] tables = Tables.empty();
    public String selectedPartyId;
    public String guardLine = GUARD_IDLE;
    public boolean doorClosed;
    public int bills;
    public int tips;
    public Service phase = Service.SERVICE;
    public List<String> log = new ArrayList<>();
    public List<String> spoken = new ArrayList<>();
    public int regularsOrdered;

    public static Night create(List<Dish> menu, List<StaffMember> staff) {
        Night state = new Night();
        state.menu = FoodMenu.copy(menu);
        state.staff = StaffRoster.copy(staff);
        state.guests.addAll(Guests.opening());
        state.guardLine = Guard.onDuty(state.staff) ? Guard.IDLE : StaffRole.GUARD.missing;
        state.note("The diner is open. Choose a table for the party at the door.");
        for (List<Guest> members : parties(state.guests, Guest.Phase.DOOR)) {
            state.announceArrival(members);
        }
        return state;
    }

    public Night copy() {
        Night copy = new Night();
        copy.elapsed = elapsed;
        copy.menu = FoodMenu.copy(menu);
        copy.staff = StaffRoster.copy(staff);
        for (Guest guest : guests) {
            copy.guests.add(guest.copy());
        }
        copy.tables = Tables.copy(tables);
        copy.selectedPartyId = selectedPartyId;
        copy.guardLine = guardLine;
        copy.doorClosed = doorClosed;
        copy.bills = bills;
        copy.tips = tips;
        copy.phase = phase;
        copy.log = new ArrayList<>(log);
        copy.spoken = new ArrayList<>(spoken);
        copy.regularsOrdered = regularsOrdered;
        return copy;
    }

    public int money() {
        return bills + tips;
    }

    public static int turnOf(long elapsed) {
        return Guests.turnOf(elapsed);
    }

    public static String turnLabel(long elapsed) {
        return Guests.turnLabel(elapsed);
    }

    public boolean victory() {
        return Guests.won(paidCount(), money());
    }

    public int paidCount() {
        int count = 0;
        for (Guest guest : guests) {
            if (guest.phase == Guest.Phase.PAID) {
                count += 1;
            }
        }
        return count;
    }

    public Guest findId(String id) {
        for (Guest guest : guests) {
            if (guest.id.equals(id)) {
                return guest;
            }
        }
        return null;
    }

    public static Guard.Decision guardParty(List<Guest> members) {
        return Guard.review(members);
    }

    public static int billFor(GuestKind kind, int priceCents, boolean happyHour) {
        return Tables.price(kind, priceCents, happyHour);
    }

    /** About one plate in ten is bad. Poisoning is rarer than a bad taste. */
    public static PlateProblem rollIncident(double roll) {
        return Waiter.roll(roll);
    }

    public static Dish chooseDish(GuestKind kind, List<Dish> menu, int regularOrdinal) {
        return Guests.chooseDish(kind, menu, regularOrdinal);
    }

    public Night selectDoorGuest(String guestId) {
        if (phase == Service.OVER) {
            return this;
        }
        Guest guest = findId(guestId);
        if (guest == null || guest.phase != Guest.Phase.DOOR) {
            return this;
        }
        Night next = copy();
        next.spoken.clear();
        next.selectedPartyId = guest.partyId;
        List<Guest> members = next.partyAtDoor();
        Guard.Decision decision = guardParty(members);
        boolean guarded = Guard.onDuty(next.staff);
        String hint = "Table 1 or table 2. Normal price.";
        if (!guarded) {
            hint = StaffRole.GUARD.missing + " Seat them at table 1.";
            next.guardLine = StaffRole.GUARD.missing;
        } else if (decision.happyHour) {
            hint = "The guard cleared Happy Hour. Table 2 is 20% off. Table 1 is the normal price.";
        } else if (decision.refusal != null) {
            hint = decision.refusal;
        }
        String verb = members.size() > 1 ? "are" : "is";
        next.note(names(members) + " " + verb + " at the door. " + hint);
        if (!guarded) {
            return next;
        }
        if (decision.refusal != null) {
            next.guardLine = decision.refusal;
        } else if (decision.happyHour) {
            next.guardLine = Guard.approval(members);
        }
        return next;
    }

    public Night seatSelected(int tableIndex) {
        if (phase == Service.OVER) {
            return this;
        }
        Night next = copy();
        next.spoken.clear();
        return next.finishSeat(next.partyAtDoor(), tableIndex);
    }

    public Night seatGroup(List<String> guestIds, int tableIndex) {
        if (phase == Service.OVER) {
            return this;
        }
        Night next = copy();
        next.spoken.clear();
        List<Guest> members = new ArrayList<>();
        for (String id : guestIds) {
            Guest guest = next.findId(id);
            if (guest == null) {
                next.note("Those guests are not all waiting at the door.");
                return next;
            }
            members.add(guest);
        }
        for (Guest guest : members) {
            if (guest.phase != Guest.Phase.DOOR) {
                next.note("Those guests are not all waiting at the door.");
                return next;
            }
        }
        return next.finishSeat(members, tableIndex);
    }

    public Night tick(long deltaMs, DoubleSupplier rng) {
        if (phase == Service.OVER || deltaMs <= 0) {
            return this;
        }
        Night next = copy();
        next.spoken.clear();
        long previous = next.elapsed;
        next.elapsed = previous + deltaMs;
        List<String> arrived = new ArrayList<>();

        for (Guest guest : next.guests) {
            if (guest.phase == Guest.Phase.DUE && guest.arriveAt < SHIFT_LENGTH_MS && next.elapsed >= guest.arriveAt) {
                guest.phase = Guest.Phase.DOOR;
                if (!arrived.contains(guest.partyId)) {
                    arrived.add(guest.partyId);
                }
            }
            if (guest.phase == Guest.Phase.DOOR) {
                long since = Math.max(previous, guest.arriveAt);
                next.applyTurnDecay(guest, turnDrops(since, Math.min(next.elapsed, SHIFT_LENGTH_MS)));
            } else if (guest.phase == Guest.Phase.COOKING) {
                boolean chef = Chef.onDuty(next.staff);
                boolean waiter = Waiter.onDuty(next.staff);
                if (!chef) {
                    next.applyTurnDecay(guest, turnDrops(previous, Math.min(next.elapsed, SHIFT_LENGTH_MS)));
                    if (guest.phase == Guest.Phase.COOKING && guest.blocked != StaffRole.CHEF) {
                        guest.blocked = StaffRole.CHEF;
                        next.note(StaffRole.CHEF.missing);
                    }
                    continue;
                }
                long until = Chef.waitingUntil(previous, next.elapsed, guest.cookMs, guest.cookNeeded, waiter, SHIFT_LENGTH_MS);
                next.applyTurnDecay(guest, turnDrops(previous, until));
                if (guest.phase != Guest.Phase.COOKING) {
                    continue;
                }
                Chef.Batch batch = Chef.cook(guest, deltaMs, true);
                if (batch.pace == Chef.Pace.READY) {
                    if (!waiter) {
                        for (String line : Waiter.hold(guest)) {
                            next.note(line);
                        }
                        continue;
                    }
                    next.serve(guest, rng);
                    guest.eatMs += batch.overshootMs;
                    if (guest.eatMs >= EAT_MS) {
                        next.settleBill(guest);
                    }
                }
            } else if (guest.phase == Guest.Phase.EATING) {
                if (guest.blocked == StaffRole.CASHIER) {
                    continue;
                }
                guest.eatMs += deltaMs;
                if (guest.eatMs >= EAT_MS) {
                    next.settleBill(guest);
                }
            }
        }

        for (String partyId : arrived) {
            List<Guest> members = new ArrayList<>();
            for (Guest member : next.guests) {
                if (member.partyId.equals(partyId) && member.phase == Guest.Phase.DOOR) {
                    members.add(member);
                }
            }
            if (!members.isEmpty()) {
                next.announceArrival(members);
            }
        }

        if (next.elapsed >= SHIFT_LENGTH_MS) {
            next.closeDoor();
            next.phase = Service.OVER;
            next.note("The shift is over.");
        }
        return next;
    }

    public Summary summary() {
        Summary summary = new Summary();
        summary.bills = bills;
        summary.tips = tips;
        summary.money = money();
        for (Guest guest : guests) {
            if (guest.phase == Guest.Phase.PAID) {
                summary.paid.add(guest.name);
                if (guest.satisfaction > TIP_ABOVE) {
                    summary.paidHappy.add(guest.name);
                }
            } else if (guest.phase == Guest.Phase.LEFT) {
                summary.left.add(guest.name);
            }
        }
        return summary;
    }

    private Night finishSeat(List<Guest> members, int tableIndex) {
        String problem = Tables.problem(tables, members, tableIndex, Guard.onDuty(staff));
        if (problem != null) {
            if (problem.equals("Tap a guest at the door first.")) {
                selectedPartyId = null;
            }
            note(problem);
            if (problem.startsWith("Guard") || problem.contains("Happy Hour") || problem.contains("No guard")) {
                guardLine = problem;
            }
            return this;
        }
        Guard.Decision decision = guardParty(members);
        boolean discount = Tables.happyHourDiscount(tableIndex, Guard.onDuty(staff), decision.happyHour);
        List<Integer> openSeats = Tables.openSeats(tables, tableIndex);
        boolean chef = Chef.onDuty(staff);
        for (int index = 0; index < members.size(); index++) {
            Guest guest = members.get(index);
            int ordinal = guest.kind == GuestKind.REGULAR ? regularsOrdered : 0;
            Dish dish = chooseDish(guest.kind, menu, ordinal);
            if (guest.kind == GuestKind.REGULAR) {
                regularsOrdered += 1;
            }
            guest.phase = Guest.Phase.COOKING;
            guest.dishName = dish.name;
            guest.happyHour = discount;
            guest.beforeHourCents = billFor(guest.kind, dish.priceCents, false);
            guest.billCents = billFor(guest.kind, dish.priceCents, discount);
            Chef.begin(guest, dish.prep, chef);
            Tables.take(tables, guest, tableIndex, openSeats.get(index));
        }
        selectedPartyId = null;
        String place = "table " + (tableIndex + 1);
        if (members.size() > 1) {
            note(names(members) + " sit together at " + place + ".");
        }
        String kitchen = Chef.kitchenLine(chef);
        for (Guest guest : members) {
            String without = guest.wantsHappyHour && !guest.happyHour ? " without Happy Hour" : "";
            note(guest.name + " sits at " + place + without + " and orders the " + guest.dishName + " for "
                    + Tables.priceWords(guest) + ". " + kitchen);
        }
        if (discount) {
            guardLine = Guard.approval(members);
        } else if (anyWantsHappyHour(members)) {
            String verb = members.size() > 1 ? "are" : "is";
            guardLine = names(members) + " " + verb + " seated without Happy Hour.";
        }
        return this;
    }

    private void serve(Guest guest, DoubleSupplier rng) {
        for (String line : Waiter.serve(guest, rng.getAsDouble())) {
            note(line);
        }
    }

    private void settleBill(Guest guest) {
    // If we are already on the final turn (Turn 18), they cannot pay this turn
    if (turnOf(elapsed) >= TURN_COUNT) {
        return;
    }
    if (!Cashier.onDuty(staff)) {
        for (String line : Cashier.refuse(guest)) {
            note(line);
        }
        return;
    }
    pay(guest);
  } 

    private void pay(Guest guest) {
        Cashier.Payment payment = Cashier.take(guest);
        bills += payment.billCents;
        tips += payment.tipCents;
        Tables.free(tables, guest);
        note(payment.line);
    }

    private void applyTurnDecay(Guest guest, int drops) {
        if (drops <= 0 || guest.phase == Guest.Phase.EATING || guest.phase == Guest.Phase.PAID || guest.phase == Guest.Phase.LEFT) {
            return;
        }
        int before = guest.satisfaction;
        guest.satisfaction = Guests.satisfactionAfter(before, drops);
        if (guest.satisfaction == 0) {
            if (guest.phase == Guest.Phase.DOOR) {
                leaveDoorParty(guest);
            } else if (guest.phase == Guest.Phase.COOKING) {
                leaveUnserved(guest);
            }
            return;
        }
        if (guest.satisfaction != before) {
            String where = guest.phase == Guest.Phase.DOOR ? "at the door" : "still waiting for food";
            note(guest.name + " loses " + (before - guest.satisfaction) + " " + where + ". Satisfaction " + guest.satisfaction + ".");
        }
    }

    private void leaveUnserved(Guest guest) {
        if (guest.phase != Guest.Phase.COOKING) {
            return;
        }
        guest.satisfaction = 0;
        guest.phase = Guest.Phase.LEFT;
        Tables.free(tables, guest);
        note(guest.name + " hits 0 before the food is served and leaves.");
    }

    private void leaveDoorParty(Guest guest) {
        if (guest.phase != Guest.Phase.DOOR) {
            return;
        }
        List<Guest> waiting = new ArrayList<>();
        for (Guest member : guests) {
            if (member.partyId.equals(guest.partyId) && member.phase == Guest.Phase.DOOR) {
                waiting.add(member);
            }
        }
        for (Guest member : waiting) {
            if (member.id.equals(guest.id)) {
                member.satisfaction = 0;
            }
            member.phase = Guest.Phase.LEFT;
        }
        if (guest.partyId.equals(selectedPartyId)) {
            selectedPartyId = null;
        }
        if (waiting.size() <= 1) {
            note(guest.name + " hits 0 at the door and leaves.");
        } else {
            note(guest.name + " hits 0 at the door and the party leaves.");
        }
    }

    private void closeDoor() {
        if (doorClosed) {
            return;
        }
        doorClosed = true;
        List<Guest> waiting = new ArrayList<>();
        for (Guest guest : guests) {
            if (guest.phase == Guest.Phase.DOOR) {
                waiting.add(guest);
            }
        }
        for (Guest guest : waiting) {
            guest.phase = Guest.Phase.LEFT;
        }
        selectedPartyId = null;
        guardLine = "The door is closed. No one else is coming in.";
        if (waiting.isEmpty()) {
            note("The door closes.");
            return;
        }
        String verb = waiting.size() == 1 ? "is" : "are";
        String leave = waiting.size() == 1 ? "leaves" : "leave";
        note("The door closes. " + names(waiting) + " " + verb + " still outside and " + leave + ".");
    }

    private void announceArrival(List<Guest> members) {
        note(walkIn(members));
        if (!Guard.onDuty(staff)) {
            guardLine = StaffRole.GUARD.missing;
            if (anyWantsHappyHour(members)) {
                note(StaffRole.GUARD.missing);
            }
            return;
        }
        Guard.Decision decision = guardParty(members);
        if (decision.refusal != null) {
            note(decision.refusal);
            guardLine = decision.refusal;
            return;
        }
        if (decision.happyHour) {
            String line = Guard.approval(members);
            note(line);
            guardLine = line;
        }
    }

    private void note(String line) {
        log.add(line);
        spoken.add(line);
        if (log.size() > 80) {
            log.subList(0, log.size() - 80).clear();
        }
    }

    private List<Guest> partyAtDoor() {
        if (selectedPartyId == null) {
            return List.of();
        }
        List<Guest> members = new ArrayList<>();
        for (Guest person : guests) {
            if (selectedPartyId.equals(person.partyId) && person.phase == Guest.Phase.DOOR) {
                members.add(person);
            }
        }
        return members;
    }

    private static String walkIn(List<Guest> members) {
        if (members.size() == 1) {
            Guest guest = members.get(0);
            String wish = guest.wantsHappyHour ? " Wants Happy Hour." : "";
            return guest.name + " walks in. " + guest.kind.label + ". Age " + guest.age + "." + wish;
        }
        List<String> ages = new ArrayList<>();
        for (Guest member : members) {
            ages.add(member.name + " " + member.age);
        }
        String wish = allWantHappyHour(members) ? " They want Happy Hour." : "";
        return names(members) + " walk in together. Party of " + members.size() + ". " + String.join(", ", ages) + "." + wish;
    }

    private static boolean anyWantsHappyHour(List<Guest> members) {
        for (Guest member : members) {
            if (member.wantsHappyHour) {
                return true;
            }
        }
        return false;
    }

    private static boolean allWantHappyHour(List<Guest> members) {
        for (Guest member : members) {
            if (!member.wantsHappyHour) {
                return false;
            }
        }
        return !members.isEmpty();
    }

    static int turnDrops(long afterExclusive, long untilInclusive) {
        return Guests.turnDrops(afterExclusive, untilInclusive);
    }

    static List<List<Guest>> parties(List<Guest> guests, Guest.Phase phase) {
        return Guests.parties(guests, phase);
    }

    static String names(List<Guest> members) {
        return Guests.names(members);
    }

    public static final class Summary {
        public int money;
        public int bills;
        public int tips;
        public final List<String> left = new ArrayList<>();
        public final List<String> paid = new ArrayList<>();
        public final List<String> paidHappy = new ArrayList<>();
    }
}

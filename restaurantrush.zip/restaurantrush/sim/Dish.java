package restaurantrush.sim;

/**
 * Represents a single menu item with an identifier, display name, 
 * price in cents, and preparation units required.
 */
public final class Dish {
    public final String id;
    public final String name;
    public final int priceCents;
    public final long prep;

    public Dish(String id, String name, int priceCents, long prep) {
        this.id = id;
        this.name = name;
        this.priceCents = priceCents;
        this.prep = prep;
    }
}
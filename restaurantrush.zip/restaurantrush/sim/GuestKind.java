package restaurantrush.sim;

public enum GuestKind {
    REGULAR("Regular"),
    VIP("VIP"),
    CRITIC("Critic");

    public final String label;

    GuestKind(String label) {
        this.label = label;
    }
}
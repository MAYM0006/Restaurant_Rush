package restaurantrush.sim;


import java.util.List;
import restaurantrush.entity.Money;

/**
 * Takes the bill, and a 15% tip when satisfaction is still above 80. If no
 * cashier is on duty, nobody pays.
 */
public final class Cashier {
    public static final int TIP_PERCENT = 15;
    public static final int TIP_ABOVE = 80;

    private Cashier() {
    }

    public static boolean onDuty(List<StaffMember> staff) {
        return StaffRoster.has(staff, StaffRole.CASHIER);
    }

    public static int tipCents(int billCents, int satisfaction) {
        if (satisfaction > TIP_ABOVE) {
            return Money.keepPercent(billCents, TIP_PERCENT);
        }
        return 0;
    }

    public static Payment take(Guest guest) {
        int tip = tipCents(guest.billCents, guest.satisfaction);
        guest.tipCents = tip;
        guest.phase = Guest.Phase.PAID;
        String line = tip > 0
                ? guest.name + " pays " + Money.dollars(guest.billCents) + " and leaves a " + Money.dollars(tip) + " tip."
                : guest.name + " pays " + Money.dollars(guest.billCents) + ".";
        return new Payment(guest.billCents, tip, line);
    }

    /** Empty when this guest was already told that nobody can take the bill. */
    public static List<String> refuse(Guest guest) {
        if (guest.blocked == StaffRole.CASHIER) {
            return List.of();
        }
        guest.blocked = StaffRole.CASHIER;
        return List.of(StaffRole.CASHIER.missing, guest.name + " does not pay.");
    }

    public static final class Payment {
        public final int billCents;
        public final int tipCents;
        public final String line;

        public Payment(int billCents, int tipCents, String line) {
            this.billCents = billCents;
            this.tipCents = tipCents;
            this.line = line;
        }

        public int totalCents() {
            return billCents + tipCents;
        }
    }
}

package restaurantrush.sim;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.function.DoubleSupplier;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import restaurantrush.entity.Money;

/**
 * Command screens for the diner: the front desk, the menu, the staff, and the
 * shift. A party at the door waits for 1 or 2. After a valid seat the kitchen
 * runs until the next party arrives or turn 18 ends.
 */
public final class Diner {
    public enum Mode {
        FRONT, MANAGEMENT, FOOD, STAFF, SHIFT
    }

    private static final Pattern ADD_DISH = Pattern.compile(
            "^add\\s+(.+?)\\s+(\\$?\\d+(?:\\.\\d{1,2})?)\\s+(\\d+)$", Pattern.CASE_INSENSITIVE);
    private static final Pattern REMOVE_NAMED = Pattern.compile("^(?:delete|remove)\\s+(.+)$", Pattern.CASE_INSENSITIVE);
    private static final Pattern ADD_STAFF = Pattern.compile(
            "^add\\s+(.+?)\\s+(guard|chef|waiter|cashier)$", Pattern.CASE_INSENSITIVE);
    private static final Pattern SEAT = Pattern.compile("^seat\\s+(.+)$", Pattern.CASE_INSENSITIVE);

    private Diner() {
    }

    public static Session open() {
        return new Session(FoodMenu.defaults(), StaffRoster.defaults());
    }

    public static Session open(List<Dish> menu, List<StaffMember> staff) {
        return new Session(FoodMenu.copy(menu), StaffRoster.copy(staff));
    }

    public static List<String> welcomeLines() {
        return List.of("Rush Diner", "1. Restaurant management", "2. Start game");
    }

    public static CommandResult handle(Session input, String raw) {
        return handle(input, raw, Math::random);
    }

    public static CommandResult handle(Session input, String raw, DoubleSupplier rng) {
        Session session = input.copy();
        String line = raw == null ? "" : raw.trim();
        String lower = line.toLowerCase(Locale.ROOT);
        if (lower.equals("quit") || lower.equals("exit")) {
            return done(session, List.of("The diner closes."), false, true, false, List.of());
        }
        if (session.pending != null) {
            return atPending(session, lower, line);
        }
        if (session.mode == Mode.FRONT) {
            return atFront(session, lower, line);
        }
        if (session.mode == Mode.MANAGEMENT) {
            return atManagement(session, lower, line);
        }
        if (session.mode == Mode.FOOD) {
            return atFood(session, lower, line);
        }
        if (session.mode == Mode.STAFF) {
            return atStaff(session, lower, line);
        }
        return atShift(session, lower, line, rng);
    }

    public static SeatRequest parseSeatCommand(String raw) {
        if (raw == null) {
            return null;
        }
        Matcher match = SEAT.matcher(raw.trim());
        if (!match.matches()) {
            return null;
        }
        String[] tokens = match.group(1).trim().split("\\s+");
        if (tokens.length < 2) {
            return null;
        }
        String tableText = tokens[tokens.length - 1];
        if (tableIndexFrom(tableText) == null) {
            return null;
        }
        String[] nameTokens = Arrays.copyOf(tokens, tokens.length - 1);
        List<String> names = new ArrayList<>();
        for (int index = 0; index < nameTokens.length; index++) {
            if (index % 2 == 0) {
                if (!nameTokens[index].matches("[A-Za-z]+")) {
                    return null;
                }
                names.add(nameTokens[index]);
            } else if (!nameTokens[index].toLowerCase(Locale.ROOT).equals("and")) {
                return null;
            }
        }
        if (names.isEmpty() || names.size() > 3) {
            return null;
        }
        if (nameTokens.length != names.size() * 2 - 1) {
            return null;
        }
        return new SeatRequest(names, tableText);
    }

    private static CommandResult atFront(Session session, String lower, String line) {
        if (lower.equals("help") || lower.equals("?")) {
            return done(session, welcomeLines());
        }
        String pick = picked(lower, new String[][] {
                { "1", "restaurant management" },
                { "2", "start game" }
        });
        if ("1".equals(pick)) {
            session.mode = Mode.MANAGEMENT;
            return done(session, managementLines());
        }
        if ("2".equals(pick)) {
            return beginShift(session);
        }
        if (line.isEmpty()) {
            return done(session, List.of("Type 1 for Restaurant management, or 2 for Start game."));
        }
        return done(session, List.of("Unknown command \"" + line + "\". Type 1 or 2."));
    }

    private static CommandResult atManagement(Session session, String lower, String line) {
        if (lower.equals("help") || lower.equals("?")) {
            return done(session, managementLines());
        }
        if (lower.equals("back")) {
            session.mode = Mode.FRONT;
            return done(session, welcomeLines());
        }
        String pick = picked(lower, new String[][] {
                { "1", "view food menu" },
                { "2", "food management" },
                { "3", "staff management" }
        });
        if ("1".equals(pick)) {
            List<String> lines = new ArrayList<>();
            lines.add("Saved food menu");
            lines.addAll(renderMenu(session.menu));
            lines.addAll(managementLines());
            return done(session, lines);
        }
        if ("2".equals(pick)) {
            session.mode = Mode.FOOD;
            return done(session, foodLines(session));
        }
        if ("3".equals(pick)) {
            session.mode = Mode.STAFF;
            return done(session, staffLines(session.staff));
        }
        if (line.isEmpty()) {
            return done(session, List.of("Type 1, 2, or 3. Type back to return."));
        }
        return done(session, List.of("Unknown command \"" + line + "\". Type help."));
    }

    private static CommandResult atFood(Session session, String lower, String line) {
        if (lower.equals("help") || lower.equals("?")) {
            return done(session, foodLines(session));
        }
        if (lower.equals("back") || lower.equals("3") || lower.equals("3.") || lower.equals("3. back")) {
            session.mode = Mode.MANAGEMENT;
            return done(session, managementLines());
        }
        Matcher added = ADD_DISH.matcher(line);
        if (added.matches()) {
            return commitDish(session, added.group(1), added.group(2), added.group(3));
        }
        Matcher removed = REMOVE_NAMED.matcher(line);
        if (removed.matches()) {
            return commitDelete(session, removed.group(1));
        }
        String pick = picked(lower, new String[][] {
                { "1", "add a food" },
                { "2", "delete a food" }
        });
        if ("1".equals(pick) || lower.equals("add")) {
            session.pending = new Pending(Pending.Kind.FOOD_NAME, null, null);
            return done(session, List.of("Name of the new food?"));
        }
        if ("2".equals(pick) || lower.equals("delete") || lower.equals("remove")) {
            session.pending = new Pending(Pending.Kind.FOOD_DELETE, null, null);
            return done(session, List.of("Type the name of the food to delete."));
        }
        if (lower.startsWith("add ")) {
            return done(session, List.of("Use add Stew 14 3, or type 1 and answer the questions."));
        }
        if (line.isEmpty()) {
            return done(session, List.of("Type 1 to add a food, 2 to delete one by name, or 3 to go back."));
        }
        return done(session, List.of("Unknown command \"" + line + "\". Type help."));
    }

    private static CommandResult atStaff(Session session, String lower, String line) {
        if (lower.equals("help") || lower.equals("?")) {
            return done(session, staffLines(session.staff));
        }
        if (lower.equals("back") || lower.equals("3") || lower.equals("3.") || lower.equals("3. back")) {
            session.mode = Mode.MANAGEMENT;
            return done(session, managementLines());
        }
        Matcher added = ADD_STAFF.matcher(line);
        if (added.matches()) {
            return commitHire(session, added.group(1), added.group(2));
        }
        Matcher removed = REMOVE_NAMED.matcher(line);
        if (removed.matches()) {
            return commitFire(session, removed.group(1));
        }
        String pick = picked(lower, new String[][] {
                { "1", "add a staff member" },
                { "2", "remove a staff member" }
        });
        if ("1".equals(pick) || lower.equals("add")) {
            session.pending = new Pending(Pending.Kind.STAFF_NAME, null, null);
            return done(session, List.of("Name of the new staff member?"));
        }
        if ("2".equals(pick) || lower.equals("remove") || lower.equals("delete")) {
            session.pending = new Pending(Pending.Kind.STAFF_REMOVE, null, null);
            return done(session, List.of("Type the name of the staff member to remove."));
        }
        if (lower.startsWith("add ")) {
            return done(session, List.of("Use add Sam waiter, or type 1 and answer the questions."));
        }
        if (line.isEmpty()) {
            return done(session, List.of("Type 1 to add a staff member, 2 to remove one by name, or 3 to go back."));
        }
        return done(session, List.of("Unknown command \"" + line + "\". Type help."));
    }

    private static CommandResult atPending(Session session, String lower, String line) {
        Pending pending = session.pending;
        if (lower.equals("help") || lower.equals("?")) {
            return done(session, List.of(pendingPrompt(pending), "Type back to cancel."));
        }
        if (line.isEmpty()) {
            return done(session, List.of(pendingPrompt(pending)));
        }
        if (cancels(session, lower, pending)) {
            session.pending = null;
            return done(session, screenFor(session));
        }
        if (pending.kind == Pending.Kind.FOOD_NAME) {
            FoodMenu.NameResult named = FoodMenu.normalize(session.menu, line);
            if (!named.ok) {
                return done(session, List.of(named.error));
            }
            session.pending = new Pending(Pending.Kind.FOOD_PRICE, named.text, null);
            return done(session, List.of("Price in dollars for " + named.text + "?"));
        }
        if (pending.kind == Pending.Kind.FOOD_PRICE) {
            if (FoodMenu.parsePriceDollars(line) == null) {
                return done(session, List.of("Enter a price in dollars, above zero."));
            }
            session.pending = new Pending(Pending.Kind.FOOD_PREP, pending.name, line.trim());
            return done(session, List.of("Prep units for " + pending.name + "? Any whole number, at least 1."));
        }
        if (pending.kind == Pending.Kind.FOOD_PREP) {
            return commitDish(session, pending.name, pending.price, line);
        }
        if (pending.kind == Pending.Kind.FOOD_DELETE) {
            return commitDelete(session, line);
        }
        if (pending.kind == Pending.Kind.STAFF_NAME) {
            StaffRoster.NameResult named = StaffRoster.normalize(session.staff, line);
            if (!named.ok) {
                return done(session, List.of(named.error));
            }
            session.pending = new Pending(Pending.Kind.STAFF_ROLE, named.text, null);
            return done(session, List.of("Role for " + named.text + "? Type guard, chef, waiter, or cashier."));
        }
        if (pending.kind == Pending.Kind.STAFF_ROLE) {
            return commitHire(session, pending.name, line);
        }
        return commitFire(session, line);
    }

    private static CommandResult atShift(Session session, String lower, String line, DoubleSupplier rng) {
        Night shift = session.shift;
        if (shift == null) {
            session.mode = Mode.FRONT;
            return done(session, join(List.of("No shift is open."), welcomeLines()));
        }
        if (shift.phase == Night.Service.OVER) {
            if (lower.equals("look") || lower.equals("status")) {
                return done(session, renderShift(shift));
            }
            if (lower.equals("help") || lower.equals("?")) {
                return done(session, shiftHelp());
            }
            if (lower.equals("next") || line.isEmpty()) {
                session.mode = Mode.FRONT;
                session.shift = null;
                return done(session, welcomeLines());
            }
            session.mode = Mode.FRONT;
            session.shift = null;
            session.pending = null;
            return atFront(session, lower, line);
        }
        if (lower.equals("help") || lower.equals("?")) {
            return done(session, join(shiftHelp(), doorPrompt(shift)));
        }
        if (lower.equals("look") || lower.equals("status")) {
            return done(session, join(renderShift(shift), doorPrompt(shift)));
        }
        if (lower.equals("1") || lower.equals("2")) {
            return chooseTable(session, lower.equals("1") ? 0 : Night.HAPPY_HOUR_TABLE, rng);
        }
        if (lower.equals("next")) {
            return passTurn(session, rng);
        }
        if (line.isEmpty()) {
            List<String> prompt = doorPrompt(shift);
            if (!prompt.isEmpty()) {
                return done(session, prompt);
            }
            return done(session, List.of("Type 1 or 2 when a party is at the door."));
        }
        if (lower.startsWith("seat ")) {
            return seatCommand(session, line, rng);
        }
        return done(session, List.of("Unknown command \"" + line + "\". Type 1 or 2."));
    }

    private static CommandResult beginShift(Session session) {
        Night shift = Night.create(session.menu, session.staff);
        session.mode = Mode.SHIFT;
        session.shift = shift;
        session.pending = null;
        return done(session, join(shift.log, renderShift(shift), doorPrompt(shift)));
    }

    private static CommandResult passTurn(Session session, DoubleSupplier rng) {
        Night shift = session.shift;
        if (shift == null) {
            return done(session, List.of("No shift is open."));
        }
        Night next = shift.tick(Night.TURN_MS, rng);
        session.shift = next;
        List<String> lines = new ArrayList<>(next.spoken);
        lines.addAll(renderShift(next));
        if (next.phase == Night.Service.OVER) {
            lines.addAll(resultLines(next));
        } else {
            lines.addAll(doorPrompt(next));
        }
        return done(session, lines);
    }

    private static CommandResult chooseTable(Session session, int tableIndex, DoubleSupplier rng) {
        Night shift = session.shift;
        if (shift == null) {
            return done(session, List.of("No shift is open."));
        }
        List<List<Guest>> parties = doorParties(shift);
        if (parties.isEmpty()) {
            return done(session, List.of("Nobody is waiting at the door."));
        }
        List<Guest> party = parties.get(0);
        if (tableIndex == Tables.HAPPY_HOUR) {
            String refused = Guard.belowEighteen(party);
            if (refused != null) {
                return done(session, join(List.of(refused), doorPrompt(shift)));
            }
        }
        Night selected = shift.selectDoorGuest(party.get(0).id);
        Night seated = selected.seatSelected(tableIndex);
        return afterSeat(session, shift, seated, rng);
    }

    private static CommandResult seatCommand(Session session, String raw, DoubleSupplier rng) {
        SeatRequest parsed = parseSeatCommand(raw);
        if (parsed == null) {
            return done(session, List.of("Use seat Ari 1, seat Dina 2, or seat Eli and Farah 2. happy means table 2."));
        }
        Integer tableIndex = tableIndexFrom(parsed.tableText);
        if (tableIndex == null || session.shift == null) {
            return done(session, List.of("Table is 1 or 2. happy means table 2."));
        }
        if (parsed.names.size() == 1) {
            return seatOne(session, parsed.names.get(0), tableIndex, rng);
        }
        return seatMany(session, parsed.names, tableIndex, rng);
    }

    private static CommandResult seatOne(Session session, String name, int tableIndex, DoubleSupplier rng) {
        Night shift = session.shift;
        if (shift == null) {
            return done(session, List.of("No shift is open."));
        }
        Guest guest = doorGuest(shift, name);
        if (guest == null) {
            return done(session, List.of(name + " is not waiting at the door."));
        }
        Night selected = shift.selectDoorGuest(guest.id);
        Night seated = selected.seatSelected(tableIndex);
        return afterSeat(session, shift, seated, rng);
    }

    private static CommandResult seatMany(Session session, List<String> names, int tableIndex, DoubleSupplier rng) {
        Night shift = session.shift;
        if (shift == null) {
            return done(session, List.of("No shift is open."));
        }
        List<String> found = new ArrayList<>();
        for (String name : names) {
            Guest guest = doorGuest(shift, name);
            if (guest == null) {
                return done(session, List.of(name + " is not waiting at the door."));
            }
            if (found.contains(guest.id)) {
                return done(session, List.of("Name each guest once."));
            }
            found.add(guest.id);
        }
        Night seated = shift.seatGroup(found, tableIndex);
        return afterSeat(session, shift, seated, rng);
    }

    private static CommandResult afterSeat(Session session, Night before, Night seated, DoubleSupplier rng) {
        List<String> lines = new ArrayList<>(seated.spoken);
        lines.addAll(renderShift(seated));
        boolean seatedSomeone = anyoneSeated(before, seated);
        if (!seatedSomeone || !doorParties(seated).isEmpty() || seated.phase == Night.Service.OVER) {
            if (seated.phase != Night.Service.OVER) {
                lines.addAll(doorPrompt(seated));
            }
            session.shift = seated;
            return done(session, lines, seatedSomeone, false, false, List.of());
        }
        KitchenRun run = runKitchen(seated, rng);
        session.shift = run.shift;
        return done(session, lines, true, false, false, run.frames);
    }

    private static KitchenRun runKitchen(Night shift, DoubleSupplier rng) {
        List<List<String>> frames = new ArrayList<>();
        Night current = shift;
        for (int step = 0; step < Night.TURN_COUNT && current.phase == Night.Service.SERVICE && doorParties(current).isEmpty(); step++) {
            List<String> previousDoor = new ArrayList<>();
            for (Guest guest : current.guests) {
                if (guest.phase == Guest.Phase.DOOR && !previousDoor.contains(guest.partyId)) {
                    previousDoor.add(guest.partyId);
                }
            }
            current = current.tick(Night.TURN_MS, rng);
            List<String> frame = new ArrayList<>(current.spoken);
            frame.addAll(renderShift(current));
            boolean arrived = false;
            for (Guest guest : current.guests) {
                if (guest.phase == Guest.Phase.DOOR && !previousDoor.contains(guest.partyId)) {
                    arrived = true;
                    break;
                }
            }
            if (current.phase == Night.Service.OVER) {
                frame.addAll(resultLines(current));
            } else if (arrived || !doorParties(current).isEmpty()) {
                frame.addAll(doorPrompt(current));
            }
            frames.add(frame);
            if (current.phase == Night.Service.OVER || arrived || !doorParties(current).isEmpty()) {
                break;
            }
        }
        return new KitchenRun(current, frames);
    }

    private static boolean anyoneSeated(Night before, Night after) {
        for (Guest guest : after.guests) {
            Guest previous = before.findId(guest.id);
            if (previous != null && previous.phase == Guest.Phase.DOOR && guest.phase == Guest.Phase.COOKING) {
                return true;
            }
        }
        return false;
    }

    private static Guest doorGuest(Night shift, String name) {
        for (Guest person : shift.guests) {
            if (person.phase == Guest.Phase.DOOR && person.name.toLowerCase(Locale.ROOT).equals(name.toLowerCase(Locale.ROOT))) {
                return person;
            }
        }
        return null;
    }

    static List<List<Guest>> doorParties(Night state) {
        List<Guest> waiting = new ArrayList<>();
        for (Guest guest : state.guests) {
            if (guest.phase == Guest.Phase.DOOR) {
                waiting.add(guest);
            }
        }
        List<Guest> ordered = new ArrayList<>(waiting);
        ordered.sort((left, right) -> {
            int byTime = Long.compare(left.arriveAt, right.arriveAt);
            if (byTime != 0) {
                return byTime;
            }
            return left.name.compareTo(right.name);
        });
        List<List<Guest>> groups = new ArrayList<>();
        List<String> seen = new ArrayList<>();
        for (Guest guest : ordered) {
            if (seen.contains(guest.partyId)) {
                continue;
            }
            seen.add(guest.partyId);
            List<Guest> group = new ArrayList<>();
            for (Guest member : waiting) {
                if (member.partyId.equals(guest.partyId)) {
                    group.add(member);
                }
            }
            groups.add(group);
        }
        return groups;
    }

    private static CommandResult commitDish(Session session, String name, String price, String prep) {
        FoodMenu.MenuChange added = FoodMenu.add(session.menu, name, price, prep);
        if (!added.ok) {
            return done(session, List.of(added.error));
        }
        session.mode = Mode.FOOD;
        session.menu = added.menu;
        session.pending = null;
        List<String> lines = new ArrayList<>();
        lines.add("Added " + added.dish.name + ", " + Money.dollars(added.dish.priceCents) + ", "
                + FoodMenu.prepLabel(added.dish.prep) + ". Saved.");
        lines.addAll(foodLines(session));
        return saved(session, lines);
    }

    private static CommandResult commitDelete(Session session, String name) {
        FoodMenu.MenuChange removed = FoodMenu.remove(session.menu, name);
        if (!removed.ok) {
            return done(session, List.of(removed.error));
        }
        session.mode = Mode.FOOD;
        session.menu = removed.menu;
        session.pending = null;
        List<String> lines = new ArrayList<>();
        lines.add("Deleted " + removed.dish.name + ". Saved.");
        lines.addAll(foodLines(session));
        return saved(session, lines);
    }

    private static CommandResult commitHire(Session session, String name, String role) {
        StaffRoster.StaffChange hired = StaffRoster.add(session.staff, name, role);
        if (!hired.ok) {
            return done(session, List.of(hired.error));
        }
        session.mode = Mode.STAFF;
        session.staff = hired.staff;
        session.pending = null;
        List<String> lines = new ArrayList<>();
        lines.add("Added " + StaffRoster.line(hired.person) + " Saved.");
        lines.addAll(staffLines(session.staff));
        return saved(session, lines);
    }

    private static CommandResult commitFire(Session session, String name) {
        StaffRoster.StaffChange fired = StaffRoster.remove(session.staff, name);
        if (!fired.ok) {
            return done(session, List.of(fired.error));
        }
        session.mode = Mode.STAFF;
        session.staff = fired.staff;
        session.pending = null;
        List<String> lines = new ArrayList<>();
        lines.add("Removed " + fired.person.name + ", " + fired.person.role.title + ".");
        if (!StaffRoster.has(session.staff, fired.person.role)) {
            lines.add(fired.person.role.missing);
        }
        lines.add("Saved.");
        lines.addAll(staffLines(session.staff));
        return saved(session, lines);
    }

    private static List<String> managementLines() {
        return List.of(
                "Restaurant management",
                "1. View Food Menu",
                "2. Food Management",
                "3. Staff Management",
                "Type back to return.");
    }

    private static List<String> foodLines(Session session) {
        List<String> lines = new ArrayList<>();
        lines.add("Food Management");
        lines.add("Add a food with a price and prep units. Prep is any whole number, at least 1.");
        lines.add("Delete a food by its name. The last dish stays.");
        lines.addAll(renderMenu(session.menu));
        lines.add("1. Add a food");
        lines.add("2. Delete a food");
        lines.add("3. Back");
        return lines;
    }

    private static List<String> staffLines(List<StaffMember> staff) {
        List<String> lines = new ArrayList<>();
        lines.add("Staff");
        lines.addAll(StaffRoster.directory(staff));
        lines.add("Removing the last guard, chef, waiter, or cashier changes the shift:");
        for (StaffRole role : StaffRole.values()) {
            lines.add(role.missing);
        }
        List<String> missing = StaffRoster.missingLines(staff);
        if (!missing.isEmpty()) {
            lines.add("Right now:");
            lines.addAll(missing);
        }
        lines.add("1. Add a staff member");
        lines.add("2. Remove a staff member");
        lines.add("3. Back");
        return lines;
    }

    private static List<String> screenFor(Session session) {
        if (session.mode == Mode.FOOD) {
            return foodLines(session);
        }
        if (session.mode == Mode.STAFF) {
            return staffLines(session.staff);
        }
        if (session.mode == Mode.MANAGEMENT) {
            return managementLines();
        }
        return welcomeLines();
    }

    private static String pendingPrompt(Pending pending) {
        if (pending.kind == Pending.Kind.FOOD_NAME) {
            return "Name of the new food?";
        }
        if (pending.kind == Pending.Kind.FOOD_PRICE) {
            return "Price in dollars for " + pending.name + "?";
        }
        if (pending.kind == Pending.Kind.FOOD_PREP) {
            return "Prep units for " + pending.name + "? Any whole number, at least 1.";
        }
        if (pending.kind == Pending.Kind.FOOD_DELETE) {
            return "Type the name of the food to delete.";
        }
        if (pending.kind == Pending.Kind.STAFF_NAME) {
            return "Name of the new staff member?";
        }
        if (pending.kind == Pending.Kind.STAFF_ROLE) {
            return "Role for " + pending.name + "? Type guard, chef, waiter, or cashier.";
        }
        return "Type the name of the staff member to remove.";
    }

    private static boolean cancels(Session session, String lower, Pending pending) {
        if (lower.equals("cancel")) {
            return true;
        }
        if (!lower.equals("back")) {
            return false;
        }
        if (pending.kind == Pending.Kind.FOOD_DELETE) {
            for (Dish dish : session.menu) {
                if (dish.name.toLowerCase(Locale.ROOT).equals("back")) {
                    return false;
                }
            }
            return true;
        }
        if (pending.kind == Pending.Kind.STAFF_REMOVE) {
            for (StaffMember person : session.staff) {
                if (person.name.toLowerCase(Locale.ROOT).equals("back")) {
                    return false;
                }
            }
            return true;
        }
        return true;
    }

    private static List<String> shiftHelp() {
        return List.of(
                "When a party is at the door, type 1 or 2.",
                "1. Table 1, dining only, normal price.",
                "2. Table 2, Happy Hour and dining.",
                "A guest under 18 cannot take table 2.",
                "After a valid choice, the kitchen runs until the next party reaches the door.",
                "seat <name> <1|2>",
                "seat <name> and <name> <1|2>",
                "look",
                "help",
                "quit",
                "Satisfaction drops by 8 on each turn while a guest is at the door or seated without food.",
                "It stops once the plate is served.");
    }

    private static Integer tableIndexFrom(String text) {
        String word = text.trim().toLowerCase(Locale.ROOT);
        if (word.equals("1") || word.equals("table1") || word.equals("t1")) {
            return 0;
        }
        if (word.equals("2") || word.equals("table2") || word.equals("t2") || word.equals("happy") || word.equals("hh")
                || word.equals("happyhour")) {
            return Night.HAPPY_HOUR_TABLE;
        }
        return null;
    }

    private static List<String> renderMenu(List<Dish> menu) {
        return FoodMenu.lines(menu);
    }

    public static List<String> renderShift(Night state) {
        List<String> lines = new ArrayList<>();
        lines.add("------------------------------------------------------------");
        lines.add(Night.turnLabel(state.elapsed));
        lines.add("Till " + Money.dollars(state.money()) + "    Paid " + state.paidCount() + "    Tips "
                + Money.dollars(state.tips));
        lines.add("Need " + Night.WIN_PAID + " paid and " + Money.dollars(Night.WIN_CENTS) + ".");
        lines.add(dutyLine(state.staff));
        lines.add(state.guardLine);
        for (String missing : StaffRoster.missingLines(state.staff)) {
            if (!missing.equals(state.guardLine)) {
                lines.add(missing);
            }
        }
        lines.add("Door:");
        List<Guest> door = new ArrayList<>();
        for (Guest guest : state.guests) {
            if (guest.phase == Guest.Phase.DOOR) {
                door.add(guest);
            }
        }
        if (door.isEmpty()) {
            lines.add("  nobody");
        } else {
            List<String> seen = new ArrayList<>();
            boolean guarded = StaffRoster.has(state.staff, StaffRole.GUARD);
            for (Guest guest : door) {
                if (seen.contains(guest.partyId)) {
                    continue;
                }
                seen.add(guest.partyId);
                List<Guest> members = new ArrayList<>();
                for (Guest person : door) {
                    if (person.partyId.equals(guest.partyId)) {
                        members.add(person);
                    }
                }
                Guard.Decision decision = Guard.review(members);
                for (Guest member : members) {
                    String wish;
                    if (!guarded) {
                        wish = "no guard, happy hour closed";
                    } else if (decision.refusal != null) {
                        wish = "guard refuses happy hour";
                    } else if (decision.happyHour) {
                        wish = "guard will allow happy hour";
                    } else {
                        wish = "regular table";
                    }
                    lines.add("  " + member.name + "  " + member.kind.label + "  age " + member.age + "  sat "
                            + member.satisfaction + "  " + wish);
                }
            }
        }
        lines.add("Tables:");
        for (int index = 0; index < state.tables.length; index++) {
            String title = Tables.label(index);
            List<Guest> sitting = new ArrayList<>();
            for (String id : state.tables[index]) {
                if (id == null) {
                    continue;
                }
                Guest guest = state.findId(id);
                if (guest != null) {
                    sitting.add(guest);
                }
            }
            if (sitting.isEmpty()) {
                lines.add("  " + title + "  empty  " + Night.SEATS_PER_TABLE + " seats");
            } else {
                lines.add("  " + title + "  " + sitting.size() + "/" + Night.SEATS_PER_TABLE);
                for (Guest guest : sitting) {
                    lines.add("    " + guestLine(guest) + "  " + plateLabel(guest) + "  " + Money.dollars(guest.billCents));
                }
            }
        }
        if (!state.doorClosed) {
            List<Guest> due = new ArrayList<>();
            for (Guest guest : state.guests) {
                if (guest.phase == Guest.Phase.DUE) {
                    due.add(guest);
                }
            }
            if (!due.isEmpty()) {
                lines.add("On the way:");
                for (Guest guest : due) {
                    lines.add("  " + guest.name + "  " + guest.kind.label + "  age " + guest.age + "  turn "
                            + Night.turnOf(guest.arriveAt));
                }
            }
        }
        lines.add("------------------------------------------------------------");
        return lines;
    }

    private static List<String> resultLines(Night state) {
        Night.Summary summary = state.summary();
        List<String> lines = new ArrayList<>();
        lines.add(state.victory() ? "VICTORY" : "DEFEAT");
        lines.add("Paid " + summary.paid.size() + "    Till " + Money.dollars(summary.money) + "    Tips "
                + Money.dollars(summary.tips));
        lines.add(summary.paid.isEmpty() ? "Nobody paid." : "Paid: " + String.join(", ", summary.paid));
        lines.add(summary.left.isEmpty() ? "Nobody walked out." : "Left: " + String.join(", ", summary.left));
        lines.add("Type 1 for Restaurant management, or 2 for Start game.");
        return lines;
    }

    private static String dutyLine(List<StaffMember> staff) {
        if (staff.isEmpty()) {
            return "On duty: nobody.";
        }
        List<String> parts = new ArrayList<>();
        for (StaffMember person : staff) {
            parts.add(person.name + ", " + person.role.title);
        }
        return "On duty: " + String.join("; ", parts);
    }

    private static String plateLabel(Guest guest) {
        if (guest.dishName == null) {
            return phaseWord(guest.phase);
        }
        if (guest.blocked == StaffRole.CHEF && guest.phase == Guest.Phase.COOKING) {
            return guest.dishName + " not cooking";
        }
        if (guest.blocked == StaffRole.WAITER && guest.phase == Guest.Phase.COOKING) {
            return guest.dishName + " ready";
        }
        if (guest.blocked == StaffRole.CASHIER && guest.phase == Guest.Phase.EATING) {
            return guest.dishName + " unpaid";
        }
        return guest.dishName + " " + phaseWord(guest.phase);
    }

    private static String phaseWord(Guest.Phase phase) {
        return switch (phase) {
            case DUE -> "due";
            case DOOR -> "door";
            case COOKING -> "cooking";
            case EATING -> "eating";
            case PAID -> "paid";
            case LEFT -> "left";
        };
    }

    private static String guestLine(Guest guest) {
        return guest.name + "  " + guest.kind.label + "  age " + guest.age + "  sat " + guest.satisfaction;
    }

    private static List<String> doorPrompt(Night state) {
        if (state.phase != Night.Service.SERVICE) {
            return List.of();
        }
        List<List<Guest>> parties = doorParties(state);
        if (parties.isEmpty()) {
            return List.of();
        }
        List<Guest> party = parties.get(0);
        List<String> lines = new ArrayList<>();
        if (party.size() == 1) {
            Guest guest = party.get(0);
            lines.add(guest.name + " is at the door. " + guest.kind.label + ". Age " + guest.age + ".");
        } else {
            lines.add(Night.names(party) + " are at the door.");
            for (Guest member : party) {
                lines.add(member.name + ", " + member.kind.label + ", age " + member.age + ".");
            }
        }
        lines.add("1. Table 1, dining only, normal price.");
        lines.add("2. Table 2, Happy Hour and dining.");
        return lines;
    }

    private static String picked(String lower, String[][] options) {
        String text = lower.replaceAll("\\s+", " ").trim();
        for (String[] option : options) {
            String number = option[0];
            String phrase = option[1];
            if (text.equals(number) || text.equals(number + ".") || text.equals(phrase)
                    || text.equals(number + " " + phrase) || text.equals(number + ". " + phrase)
                    || text.equals(number + "." + phrase)) {
                return number;
            }
        }
        return null;
    }

    @SafeVarargs
    private static List<String> join(List<String>... parts) {
        List<String> lines = new ArrayList<>();
        for (List<String> part : parts) {
            lines.addAll(part);
        }
        return lines;
    }

    private static CommandResult done(Session session, List<String> lines) {
        return done(session, lines, false, false, false, List.of());
    }

    private static CommandResult saved(Session session, List<String> lines) {
        return done(session, lines, false, false, true, List.of());
    }

    private static CommandResult done(Session session, List<String> lines, boolean advance, boolean quit, boolean save,
            List<List<String>> frames) {
        return new CommandResult(session, lines, save, quit, advance, frames);
    }

    public static final class Session {
        public Mode mode = Mode.FRONT;
        public List<Dish> menu;
        public List<StaffMember> staff;
        public Night shift;
        public Pending pending;

        Session(List<Dish> menu, List<StaffMember> staff) {
            this.menu = menu;
            this.staff = staff;
        }

        public Session copy() {
            Session copy = new Session(FoodMenu.copy(menu), StaffRoster.copy(staff));
            copy.mode = mode;
            copy.shift = shift == null ? null : shift.copy();
            copy.pending = pending;
            return copy;
        }
    }

    public static final class Pending {
        enum Kind {
            FOOD_NAME, FOOD_PRICE, FOOD_PREP, FOOD_DELETE, STAFF_NAME, STAFF_ROLE, STAFF_REMOVE
        }

        final Kind kind;
        final String name;
        final String price;

        Pending(Kind kind, String name, String price) {
            this.kind = kind;
            this.name = name;
            this.price = price;
        }
    }

    public static final class SeatRequest {
        public final List<String> names;
        public final String tableText;

        SeatRequest(List<String> names, String tableText) {
            this.names = names;
            this.tableText = tableText;
        }
    }

    public static final class CommandResult {
        public final Session session;
        public final List<String> lines;
        public final boolean save;
        public final boolean quit;
        public final boolean advance;
        public final List<List<String>> frames;

        CommandResult(Session session, List<String> lines, boolean save, boolean quit, boolean advance,
                List<List<String>> frames) {
            this.session = session;
            this.lines = lines;
            this.save = save;
            this.quit = quit;
            this.advance = advance;
            this.frames = frames;
        }
    }

    private static final class KitchenRun {
        final Night shift;
        final List<List<String>> frames;

        KitchenRun(Night shift, List<List<String>> frames) {
            this.shift = shift;
            this.frames = frames;
        }
    }
}

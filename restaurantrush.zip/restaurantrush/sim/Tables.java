package restaurantrush.sim;

import java.util.ArrayList;
import java.util.List;
import restaurantrush.entity.Money;

public final class Tables {
    public static final int COUNT = 2;
    public static final int SEATS = 2;
    public static final int HAPPY_HOUR_TABLE = 1;
    public static final int HAPPY_HOUR = 1;
    public static final int HAPPY_HOUR_KEEP = 80; // 20% off -> keep 80%

    private Tables() {}

    public static String[][] empty() {
        return new String[COUNT][SEATS];
    }

    public static String[][] copy(String[][] tables) {
        String[][] copy = new String[tables.length][];
        for (int i = 0; i < tables.length; i++) {
            copy[i] = tables[i].clone();
        }
        return copy;
    }

    public static String label(int index) {
        return "Table " + (index + 1);
    }

    public static List<Integer> openSeats(String[][] tables, int tableIndex) {
        List<Integer> seats = new ArrayList<>();
        for (int seat = 0; seat < tables[tableIndex].length; seat++) {
            if (tables[tableIndex][seat] == null) {
                seats.add(seat);
            }
        }
        return seats;
    }

    public static void take(String[][] tables, Guest guest, int tableIndex, int seatIndex) {
        tables[tableIndex][seatIndex] = guest.id;
    }

    public static void free(String[][] tables, Guest guest) {
        for (int i = 0; i < tables.length; i++) {
            for (int j = 0; j < tables[i].length; j++) {
                if (guest.id.equals(tables[i][j])) {
                    tables[i][j] = null;
                }
            }
        }
    }

    public static String problem(String[][] tables, List<Guest> members, int tableIndex, boolean guardOnDuty) {
        if (members.isEmpty()) {
            return "Tap a guest at the door first.";
        }
        List<Integer> open = openSeats(tables, tableIndex);
        if (open.size() < members.size()) {
            return "Not enough open seats at " + label(tableIndex) + ".";
        }
        if (tableIndex == HAPPY_HOUR_TABLE) {
            String minorError = Guard.belowEighteen(members);
            if (minorError != null) {
                return minorError;
            }
        }
        return null;
    }

    public static boolean happyHourDiscount(int tableIndex, boolean guardOnDuty, boolean partyWantsHappyHour) {
        return tableIndex == HAPPY_HOUR_TABLE && guardOnDuty && partyWantsHappyHour;
    }

    public static int price(GuestKind kind, int priceCents, boolean happyHour) {
        int base = priceCents;
        if (kind == GuestKind.VIP) {
            base = Money.keepPercent(base, 90); // 10% off for VIP
        }
        if (happyHour) {
            base = Money.keepPercent(base, HAPPY_HOUR_KEEP); // 20% off during Happy Hour
        }
        return base;
    }

    public static String priceWords(Guest guest) {
        if (guest.happyHour) {
            return Money.dollars(guest.billCents) + " (Happy Hour)";
        }
        return Money.dollars(guest.billCents);
    }
}
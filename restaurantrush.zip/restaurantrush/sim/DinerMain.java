package restaurantrush.sim;

import java.util.List;
import java.util.Scanner;
import java.util.concurrent.ThreadLocalRandom;
import java.util.function.DoubleSupplier;

/**
 * Wires the diner classes and reads every answer with {@link Scanner#nextLine()}.
 * The menu, the roster, the guard, the chef, the waiter, the cashier, the
 * tables, and the guests each live in their own class. This program runs them
 * as one text game. {@code restaurantrush.Main} is a different program.
 */
public final class DinerMain {
    public static final String TURN_LINE = "The turn passes...";
    public static final long TURN_PAUSE_MS = 1000;

    private DinerMain() {
    }

    public static void main(String[] args) {
        FoodMenu menu = FoodMenu.opening();
        StaffRoster roster = StaffRoster.opening();
        DoubleSupplier rng = () -> ThreadLocalRandom.current().nextDouble();
        Scanner scanner = new Scanner(System.in);
        Diner.Session session = Diner.open(menu.dishes(), roster.members());
        for (String line : Diner.welcomeLines()) {
            System.out.println(line);
        }
        while (true) {
            System.out.print("> ");
            System.out.flush();
            if (!scanner.hasNextLine()) {
                break;
            }
            Diner.CommandResult result = Diner.handle(session, scanner.nextLine(), rng);
            session = result.session;
            for (String line : result.lines) {
                System.out.println(line);
            }
            if (result.quit) {
                break;
            }
            play(result.frames);
        }
    }

    private static void play(List<List<String>> frames) {
        for (List<String> frame : frames) {
            System.out.println(TURN_LINE);
            try {
                Thread.sleep(TURN_PAUSE_MS);
            } catch (InterruptedException ex) {
                Thread.currentThread().interrupt();
            }
            for (String line : frame) {
                System.out.println(line);
            }
        }
    }
}

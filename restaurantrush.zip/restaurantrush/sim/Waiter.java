package restaurantrush.sim;

import java.util.List;

public final class Waiter {
    private Waiter() {}

    public static boolean onDuty(List<StaffMember> staff) {
        return StaffRoster.has(staff, StaffRole.WAITER);
    }

    public static List<String> hold(Guest guest) {
        return List.of(guest.name + "'s order is ready, but no waiter is on duty to serve it.");
    }

    public static List<String> serve(Guest guest, double roll) {
        guest.phase = Guest.Phase.EATING;
        guest.cookMs = 0;
        return List.of(guest.name + "'s order is served.");
    }

    public static PlateProblem roll(double roll) {
        return new PlateProblem(false, null);
    }

    
  }

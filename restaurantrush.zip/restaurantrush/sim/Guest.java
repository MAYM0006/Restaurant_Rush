package restaurantrush.sim;

public final class Guest {
    public enum Phase {
        DUE, DOOR, COOKING, EATING, PAID, LEFT
    }

    public String id;
    public String name;
    public GuestKind kind = GuestKind.REGULAR;
    public int age;
    public String partyId;
    public boolean wantsHappyHour;
    public long arriveAt;
    public int satisfaction = 100;
    public Phase phase = Phase.DUE;
    
    public long prep;
    public long cookMs;
    public long cookNeeded;
    public String dishName;
    public boolean happyHour;
    public int beforeHourCents;
    public int billCents;
    public int tipCents;
    public long eatMs;
    public StaffRole blocked;

    public Guest copy() {
        Guest copy = new Guest();
        copy.id = id;
        copy.name = name;
        copy.kind = kind;
        copy.age = age;
        copy.partyId = partyId;
        copy.wantsHappyHour = wantsHappyHour;
        copy.arriveAt = arriveAt;
        copy.satisfaction = satisfaction;
        copy.phase = phase;
        copy.prep = prep;
        copy.cookMs = cookMs;
        copy.cookNeeded = cookNeeded;
        copy.dishName = dishName;
        copy.happyHour = happyHour;
        copy.beforeHourCents = beforeHourCents;
        copy.billCents = billCents;
        copy.tipCents = tipCents;
        copy.eatMs = eatMs;
        copy.blocked = blocked;
        return copy;
    }
}
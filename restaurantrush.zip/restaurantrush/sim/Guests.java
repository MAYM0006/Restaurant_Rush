package restaurantrush.sim;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * The night's guests. Ari, Blair, Chen, Dina, Eli, and Farah arrive 
 * one by one at turns 1, 4, 7, 10, 13, and 16. The shift is 18 turns.
 */
public final class Guests {
    public static final int TURN_COUNT = 18;
    public static final long TURN_MS = 5_000;
    public static final long SHIFT_LENGTH_MS = TURN_COUNT * TURN_MS;
    public static final int WIN_PAID = 4;
    public static final int WIN_CENTS = 4_500;
    public static final int TURN_DECAY = 8;
    public static final long EAT_MS = 6000;

    private static final Arrival[] ARRIVALS = {
            new Arrival("Ari", GuestKind.REGULAR, 27, "ari", false, 0),
            new Arrival("Blair", GuestKind.CRITIC, 44, "blair", false, 15_000),
            new Arrival("Chen", GuestKind.REGULAR, 16, "chen", true, 30_000),
            new Arrival("Dina", GuestKind.VIP, 31, "dina", true, 45_000),
            new Arrival("Eli", GuestKind.REGULAR, 23, "eli", true, 60_000),          // Turn 13
            new Arrival("Farah", GuestKind.REGULAR, 17, "farah", true, 75_000)       // Turn 16
    };

    private static Arrival newNav(String name, GuestKind kind, int age, String party, boolean wantsHappyHour, long arriveAt) {
        return new Arrival(name, kind, age, party, wantsHappyHour, arriveAt);
    }

    private Guests() {
    }

    public static List<Guest> opening() {
        List<Guest> guests = new ArrayList<>();
        for (Arrival plan : ARRIVALS) {
            Guest guest = new Guest();
            guest.id = plan.name;
            guest.name = plan.name;
            guest.kind = plan.kind;
            guest.age = plan.age;
            guest.partyId = plan.party;
            guest.wantsHappyHour = plan.wantsHappyHour;
            guest.arriveAt = plan.arriveAt;
            guest.satisfaction = 100;
            guest.phase = plan.arriveAt <= 0 ? Guest.Phase.DOOR : Guest.Phase.DUE;
            guests.add(guest);
        }
        return guests;
    }

    public static boolean won(int paid, int tillCents) {
        return paid >= WIN_PAID && tillCents >= WIN_CENTS;
    }

    public static int turnOf(long elapsed) {
        if (elapsed >= SHIFT_LENGTH_MS) {
            return TURN_COUNT;
        }
        long safe = Math.max(0, elapsed);
        return (int) Math.min(TURN_COUNT, safe / TURN_MS + 1);
    }

    public static String turnLabel(long elapsed) {
        return "Turn " + turnOf(elapsed) + " of " + TURN_COUNT;
    }

    public static int satisfactionAfter(int satisfaction, int drops) {
        if (drops <= 0) {
            return satisfaction;
        }
        long next = satisfaction - (long) drops * TURN_DECAY;
        if (next <= 0) {
            return 0;
        }
        return (int) next;
    }

    public static Dish chooseDish(GuestKind kind, List<Dish> menu, int regularOrdinal) {
        if (menu.isEmpty()) {
            throw new IllegalStateException("The menu is empty.");
        }
        Dish vip = highestPrice(menu);
        Dish critic = highestPrep(menu);
        if (kind == GuestKind.VIP) {
            return vip;
        }
        if (kind == GuestKind.CRITIC) {
            return critic;
        }
        List<Dish> normal = new ArrayList<>();
        for (Dish dish : menu) {
            if (!dish.id.equals(vip.id) && !dish.id.equals(critic.id)) {
                normal.add(dish);
            }
        }
        List<Dish> pool = normal.isEmpty() ? menu : normal;
        int index = Math.floorMod(regularOrdinal, pool.size());
        return pool.get(index);
    }

    public static int turnDrops(long afterExclusive, long untilInclusive) {
        long until = Math.min(untilInclusive, SHIFT_LENGTH_MS);
        if (until <= afterExclusive) {
            return 0;
        }
        long first = Math.floorDiv(afterExclusive, TURN_MS) + 1;
        long last = Math.floorDiv(until, TURN_MS);
        long drops = last - first + 1;
        if (drops <= 0) {
            return 0;
        }
        return drops > Integer.MAX_VALUE ? Integer.MAX_VALUE : (int) drops;
    }

    public static List<List<Guest>> parties(List<Guest> guests, Guest.Phase phase) {
        List<List<Guest>> groups = new ArrayList<>();
        List<String> seen = new ArrayList<>();
        for (Guest guest : guests) {
            if (guest.phase != phase || seen.contains(guest.partyId)) {
                continue;
            }
            seen.add(guest.partyId);
            List<Guest> group = new ArrayList<>();
            for (Guest member : guests) {
                if (member.partyId.equals(guest.partyId) && member.phase == phase) {
                    group.add(member);
                }
            }
            groups.add(group);
        }
        return groups;
    }

    public static String names(List<Guest> members) {
        if (members.size() <= 1) {
            return members.isEmpty() ? "The party" : members.get(0).name;
        }
        if (members.size() == 2) {
            return members.get(0).name + " and " + members.get(1).name;
        }
        List<String> leading = new ArrayList<>();
        for (int index = 0; index < members.size() - 1; index++) {
            leading.add(members.get(index).name);
        }
        return String.join(", ", leading) + ", and " + members.get(members.size() - 1).name;
    }

    private static Dish highestPrice(List<Dish> menu) {
        return menu.stream().max(Comparator
                .comparingInt((Dish dish) -> dish.priceCents)
                .thenComparingLong(dish -> dish.prep)
                .thenComparing(Comparator.comparing((Dish dish) -> dish.name).reversed()))
                .orElseThrow();
    }

    private static Dish highestPrep(List<Dish> menu) {
        return menu.stream().max(Comparator
                .comparingLong((Dish dish) -> dish.prep)
                .thenComparingInt(dish -> dish.priceCents)
                .thenComparing(Comparator.comparing((Dish dish) -> dish.name).reversed()))
                .orElseThrow();
    }

    private static final class Arrival {
        final String name;
        final GuestKind kind;
        final int age;
        final String party;
        final boolean wantsHappyHour;
        final long arriveAt;

        Arrival(String name, GuestKind kind, int age, String party, boolean wantsHappyHour, long arriveAt) {
            this.name = name;
            this.kind = kind;
            this.age = age;
            this.party = party;
            this.wantsHappyHour = wantsHappyHour;
            this.arriveAt = arriveAt;
        }
    }
}
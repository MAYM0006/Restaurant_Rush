package restaurantrush.sim;

/**
 * Represents an individual employee on the restaurant roster,
 * holding an ID, name, and their assigned StaffRole.
 */
public final class StaffMember {
    public final String id;
    public final String name;
    public final StaffRole role;

    public StaffMember(String id, String name, StaffRole role) {
        this.id = id;
        this.name = name;
        this.role = role;
    }

    public StaffMember copy() {
        return new StaffMember(id, name, role);
    }
}
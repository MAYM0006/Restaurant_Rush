package restaurantrush.sim;

public final class PlateProblem {
    public final boolean poisoned;
    public final String description;

    public PlateProblem(boolean poisoned, String description) {
        this.poisoned = poisoned;
        this.description = description;
    }
}
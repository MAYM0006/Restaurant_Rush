#!/bin/bash
mkdir -p build
javac -d build -sourcepath src src/restaurantrush/ui/RestaurantRushCLI.java tests/RuleChecks.java || exit 1
java -cp build RuleChecks

import restaurantrush.controller.GameController;
import restaurantrush.customer.CustomerFactory;
import restaurantrush.customer.CustomerState;
import restaurantrush.customer.VIPCustomer;
import restaurantrush.domain.BillCalculator;
import restaurantrush.domain.ComboMeal;
import restaurantrush.domain.MenuItem;
import restaurantrush.exception.InvalidGameActionException;
import restaurantrush.ui.ActionEnums.ChefAction;
import restaurantrush.ui.ActionEnums.HostAction;
import restaurantrush.ui.ActionEnums.WaiterAction;

/** Plain-Java rule checks for the brief's Stage 3 requirements. Exits with status 1 if any check fails. */
public class RuleChecks {
    private static int failures = 0;

    private static void check(boolean ok, String message) {
        if (!ok) failures++;
        System.out.println((ok ? "PASS " : "FAIL ") + message);
    }

    private static WaiterAction waiter(WaiterAction.Type type, int table) { return new WaiterAction(type, table); }
    private static ChefAction chef(ChefAction.Type type, int table) { return new ChefAction(type, table); }
    private static HostAction host(HostAction.Type type, int table) { return new HostAction(type, table); }

    private static final WaiterAction WAITER_WAIT = waiter(WaiterAction.Type.WAIT, 0);
    private static final ChefAction CHEF_WAIT = chef(ChefAction.Type.WAIT, 0);
    private static final HostAction HOST_WAIT = host(HostAction.Type.WAIT, 0);

    private static boolean rejected(Runnable action) {
        try {
            action.run();
            return false;
        } catch (InvalidGameActionException e) {
            return true;
        }
    }

    /** Plays one turn with the given choices, starting the turn first. */
    private static void turn(GameController g, WaiterAction w, ChefAction c, HostAction h) {
        g.startTurnStep1();
        g.executeRemainingSteps(w, c, h);
    }

    public static void main(String[] args) {
        pricing();
        paymentTiming();
        happyHour();
        rejectedMoves();

        System.out.println(failures == 0 ? "ALL CHECKS PASSED" : failures + " CHECK(S) FAILED");
        if (failures > 0) System.exit(1);
    }

    private static void pricing() {
        ComboMeal saladPasta = new ComboMeal(MenuItem.SALAD, MenuItem.PASTA);
        check(saladPasta.getPriceCents() == 2430 && saladPasta.getRequiredPrepUnits() == 3,
                "Salad + Pasta combo costs $24.30 and needs 3 prep units");
        check(BillCalculator.calculateBill(1500, new VIPCustomer("v"), true) == 1080,
                "VIP Burger during Happy Hour costs $10.80 (VIP discount first, then 20% off)");
        check(CustomerFactory.createCustomerForTurn(7).chooseFood().getName().contains("Combo"),
                "the VIP (turn 7) orders a combo");
    }

    private static void paymentTiming() {
        GameController g = new GameController();
        turn(g, waiter(WaiterAction.Type.TAKE_ORDER, 1), chef(ChefAction.Type.COOK, 1), host(HostAction.Type.SEAT, 1));
        turn(g, WAITER_WAIT, chef(ChefAction.Type.COOK, 1), HOST_WAIT);
        turn(g, waiter(WaiterAction.Type.SERVE, 1), CHEF_WAIT, HOST_WAIT);
        check(g.getTables().get(0).getCustomer().getStatus() == CustomerState.SERVED,
                "turn 3: customer is SERVED after the Waiter serves");

        g.startTurnStep1();
        check(rejected(() -> g.executeRemainingSteps(waiter(WaiterAction.Type.SERVE, 1), CHEF_WAIT, HOST_WAIT)),
                "turn 4: serving an already-served table is rejected");
        g.executeRemainingSteps(WAITER_WAIT, CHEF_WAIT, HOST_WAIT);
        check(g.getTables().get(0).getCustomer().getStatus() == CustomerState.READY_TO_PAY
                && g.getPaidCustomers().isEmpty(), "turn 4: customer is READY_TO_PAY but has not paid yet");

        turn(g, WAITER_WAIT, CHEF_WAIT, HOST_WAIT);
        check(g.getPaidCustomers().size() == 1 && g.getTotalRevenueDollars() == 18.0,
                "turn 5: customer pays $18.00 and the table is freed");
    }

    private static void happyHour() {
        GameController g = new GameController();
        // This order is taken BEFORE Happy Hour, so it must never be discounted.
        turn(g, waiter(WaiterAction.Type.TAKE_ORDER, 1), chef(ChefAction.Type.COOK, 1), host(HostAction.Type.SEAT, 1));

        g.startTurnStep1();
        check(rejected(() -> g.executeRemainingSteps(waiter(WaiterAction.Type.SERVE, 2), CHEF_WAIT, HOST_WAIT, true)),
                "a rejected turn that asked for Happy Hour is refused");
        check(!g.isHappyHourActive() && g.canActivateHappyHour(),
                "the rejected turn did NOT use up Happy Hour");

        g.executeRemainingSteps(WAITER_WAIT, chef(ChefAction.Type.COOK, 1), HOST_WAIT, true);
        check(g.isHappyHourActive() && g.getHappyHourTurnsRemaining() == 1 && !g.canActivateHappyHour(),
                "Happy Hour is active with 1 turn left and cannot be started again");

        g.startTurnStep1();
        check(rejected(() -> g.executeRemainingSteps(WAITER_WAIT, CHEF_WAIT, HOST_WAIT, true)),
                "starting Happy Hour while it is active is rejected");
        g.executeRemainingSteps(waiter(WaiterAction.Type.SERVE, 1), CHEF_WAIT, HOST_WAIT);
        check(!g.isHappyHourActive(), "Happy Hour lasts for the activation turn and the next only");

        turn(g, WAITER_WAIT, CHEF_WAIT, HOST_WAIT);
        turn(g, WAITER_WAIT, CHEF_WAIT, HOST_WAIT);
        check(g.getTotalRevenueDollars() == 18.0,
                "an order taken before Happy Hour still pays full price (got " + g.getTotalRevenueDollars() + ")");

        g.startTurnStep1();
        check(rejected(() -> g.executeRemainingSteps(WAITER_WAIT, CHEF_WAIT, HOST_WAIT, true)),
                "Happy Hour cannot be used a second time in the same game");

        GameController r = new GameController();
        turn(r, WAITER_WAIT, CHEF_WAIT, HOST_WAIT); // customer waits: 100 -> 92
        r.startTurnStep1();
        r.executeRemainingSteps(WAITER_WAIT, CHEF_WAIT, HOST_WAIT, true); // +15 (capped at 100), then -8
        check(r.getWaitingQueue().peek().getSatisfaction() == 92,
                "Happy Hour turn 1: satisfaction recovers, then decays -> 92");
        r.startTurnStep1();
        check(r.getWaitingQueue().peek().getSatisfaction() == 100,
                "Happy Hour turn 2: +15 at turn start -> 100");
    }

    private static void rejectedMoves() {
        GameController g = new GameController();
        g.startTurnStep1();
        check(rejected(() -> g.executeRemainingSteps(WAITER_WAIT, CHEF_WAIT, host(HostAction.Type.SEAT, 3))),
                "Host seating at table 3 is rejected");
        check(rejected(() -> g.executeRemainingSteps(waiter(WaiterAction.Type.SEAT, 1), CHEF_WAIT,
                host(HostAction.Type.SEAT, 2))), "Host and Waiter both seating with 1 customer queued is rejected");
        check(g.getWaitingQueue().size() == 1 && g.getCurrentTurn() == 1,
                "rejected moves leave the queue and turn number unchanged");
    }
}

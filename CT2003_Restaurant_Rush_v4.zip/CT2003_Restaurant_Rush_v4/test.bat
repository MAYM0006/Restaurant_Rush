@echo off
if not exist build mkdir build
javac -d build -sourcepath src src/restaurantrush/ui/RestaurantRushCLI.java tests/RuleChecks.java
if errorlevel 1 exit /b 1
java -cp build RuleChecks
pause

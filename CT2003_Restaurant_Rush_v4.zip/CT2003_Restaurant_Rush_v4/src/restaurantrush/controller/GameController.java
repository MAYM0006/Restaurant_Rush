package restaurantrush.controller;

import restaurantrush.customer.Customer;
import restaurantrush.customer.CustomerFactory;
import restaurantrush.customer.CustomerState;
import restaurantrush.domain.BillCalculator;
import restaurantrush.domain.Order;
import restaurantrush.domain.Table;
import restaurantrush.exception.InvalidGameActionException;
import restaurantrush.staff.Cashier;
import restaurantrush.staff.Chef;
import restaurantrush.staff.Host;
import restaurantrush.staff.Waiter;
import restaurantrush.ui.ActionEnums.*;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

public class GameController {
    public static final int MAX_TURNS = 18;
    private static final int[] ARRIVAL_TURNS = {1, 4, 7, 10, 13, 16};

    private int currentTurn;
    private int totalRevenueCents;
    private int happyHourTurnsRemaining;
    private boolean happyHourUsed;
    private int servedCount;

    private final List<String> turnEvents = new ArrayList<>();
    private final List<Table> tables;
    private final Queue<Customer> waitingQueue;
    private final List<Customer> paidCustomers;
    private final List<Customer> abandonedCustomers;

    private final Waiter waiter;
    private final Chef chef;
    private final Host host;
    private final Cashier cashier;

    public GameController() {
        this.currentTurn = 1;
        this.totalRevenueCents = 0;
        this.happyHourTurnsRemaining = 0;

        this.tables = List.of(new Table(1), new Table(2));
        this.waitingQueue = new LinkedList<>();
        this.paidCustomers = new ArrayList<>();
        this.abandonedCustomers = new ArrayList<>();

        this.waiter = new Waiter();
        this.chef = new Chef();
        this.host = new Host();
        this.cashier = new Cashier();
    }

    public void startTurnStep1() {
        turnEvents.clear();
        resetStaffTurnCapacity();
        step1_ArrivalsAndHappyHour();
    }

    public void executeRemainingSteps(WaiterAction waiterChoice, ChefAction chefChoice, HostAction hostChoice) {
        executeRemainingSteps(waiterChoice, chefChoice, hostChoice, false);
    }

    /**
     * Runs steps 2-6 of the turn. Happy Hour is requested here rather than switched on beforehand,
     * so a rejected turn never uses it up.
     *
     * @throws InvalidGameActionException if any choice is invalid; no state has changed in that case
     */
    public void executeRemainingSteps(WaiterAction waiterChoice, ChefAction chefChoice, HostAction hostChoice,
                                      boolean activateHappyHour) {
        // Step 2 & 3: Validate all actions first, then execute atomically
        validateAllActions(waiterChoice, chefChoice, hostChoice);
        if (activateHappyHour) {
            activateHappyHour();
        }
        step2And3_ExecuteStaffActions(waiterChoice, chefChoice, hostChoice);

        step4_EatingAndPayment();
        step5_WaitingAndAbandonment();
        step6_AdvanceTurn();
    }

    private void resetStaffTurnCapacity() {
        waiter.resetTurn();
        chef.resetTurn();
        host.resetTurn();
        cashier.resetTurn();
    }

    private void step1_ArrivalsAndHappyHour() {
        if (happyHourTurnsRemaining > 0) {
            applyHappyHourRecovery();
        }

        for (int turn : ARRIVAL_TURNS) {
            if (currentTurn == turn) {
                Customer newCustomer = spawnCustomerForTurn(currentTurn);
                newCustomer.setStatus(CustomerState.WAITING);
                newCustomer.setArrivalTurn(currentTurn);
                waitingQueue.add(newCustomer);
                turnEvents.add(newCustomer.getId() + " arrives (" + newCustomer.getClass().getSimpleName()
                        + ", satisfaction 100).");
                break;
            }
        }
    }

    /** Happy Hour: customers still waiting for a table or food recover 15 satisfaction (max 100). */
    private void applyHappyHourRecovery() {
        for (Customer c : waitingQueue) {
            c.restoreSatisfaction(15);
        }
        for (Table t : tables) {
            if (t.isOccupied() && t.getCustomer().getStatus() == CustomerState.SEATED) {
                t.getCustomer().restoreSatisfaction(15);
            }
        }
    }

    /**
     * Validates all requested actions upfront BEFORE mutating any state or consuming capacity.
     */
    private void validateAllActions(WaiterAction waiterChoice, ChefAction chefChoice, HostAction hostChoice) {
        int simulatedQueueSize = waitingQueue.size();
        Table t1 = getTableByNumber(1);
        Table t2 = getTableByNumber(2);

        boolean t1Occupied = t1.isOccupied();
        boolean t2Occupied = t2.isOccupied();

        // Track order presence for validation checks
        boolean t1HasOrder = t1.isOccupied() && t1.getOrder() != null;
        boolean t2HasOrder = t2.isOccupied() && t2.getOrder() != null;

        // 1. Validate Host Action
        if (hostChoice != null && hostChoice.getType() == HostAction.Type.SEAT) {
            if (!host.isActionAvailable()) {
                throw new InvalidGameActionException("Host has no remaining action capacity.");
            }
            if (simulatedQueueSize == 0) {
                throw new InvalidGameActionException("Host cannot seat: Waiting queue is empty.");
            }
            int tNum = hostChoice.getTableNumber();
            getTableByNumber(tNum); // rejects unknown table numbers before anything runs
            if ((tNum == 1 && t1Occupied) || (tNum == 2 && t2Occupied)) {
                throw new InvalidGameActionException("Host cannot seat: Table " + tNum + " is already occupied.");
            }

            simulatedQueueSize--;
            if (tNum == 1) t1Occupied = true;
            if (tNum == 2) t2Occupied = true;
        }

        // 2. Validate Waiter Action
        if (waiterChoice != null && waiterChoice.getType() != WaiterAction.Type.WAIT) {
            if (!waiter.isActionAvailable()) {
                throw new InvalidGameActionException("Waiter has no remaining action capacity.");
            }
            Table target = getTableByNumber(waiterChoice.getTableNumber());
            boolean targetOccupied = (waiterChoice.getTableNumber() == 1) ? t1Occupied : t2Occupied;
            boolean targetHasOrder = (waiterChoice.getTableNumber() == 1) ? t1HasOrder : t2HasOrder;

            switch (waiterChoice.getType()) {
                case SEAT:
                    if (simulatedQueueSize == 0) {
                        throw new InvalidGameActionException("Waiter cannot seat: Waiting queue is empty.");
                    }
                    if (targetOccupied) {
                        throw new InvalidGameActionException("Waiter cannot seat: Table " + target.getTableNumber() + " is occupied.");
                    }
                    break;
                case TAKE_ORDER:
                    if (!targetOccupied) {
                        throw new InvalidGameActionException("Waiter cannot take order: Table " + target.getTableNumber() + " is empty.");
                    }
                    if (targetHasOrder) {
                        throw new InvalidGameActionException("Waiter cannot take order: Table " + target.getTableNumber() + " already has an order.");
                    }
                    
                    // Simulate order being taken so Chef validation passes on the same turn!
                    if (waiterChoice.getTableNumber() == 1) t1HasOrder = true;
                    if (waiterChoice.getTableNumber() == 2) t2HasOrder = true;
                    break;
                case SERVE:
                    if (!targetOccupied || !targetHasOrder) {
                        throw new InvalidGameActionException("Waiter cannot serve: No order on Table " + target.getTableNumber());
                    }
                    if (!target.getOrder().isReady()) {
                        throw new InvalidGameActionException("Waiter cannot serve: Order on Table " + target.getTableNumber() + " is not READY yet.");
                    }
                    if (target.getCustomer().getStatus() != CustomerState.SEATED) {
                        throw new InvalidGameActionException("Waiter cannot serve: Table " + target.getTableNumber() + " has already been served.");
                    }
                    break;
            }
        }

        // 3. Validate Chef Action
        if (chefChoice != null && chefChoice.getType() == ChefAction.Type.COOK) {
            if (!chef.isActionAvailable()) {
                throw new InvalidGameActionException("Chef has no remaining cooking capacity.");
            }
            Table target = getTableByNumber(chefChoice.getTableNumber());
            boolean targetHasOrder = (chefChoice.getTableNumber() == 1) ? t1HasOrder : t2HasOrder;

            if (!targetHasOrder) {
                throw new InvalidGameActionException("Chef cannot cook: No active order on Table " + target.getTableNumber());
            }

            // Only check if already ready if order existed prior to this turn
            if (target.getOrder() != null && target.getOrder().isReady()) {
                throw new InvalidGameActionException("Chef cannot cook: Order on Table " + target.getTableNumber() + " is already READY.");
            }
        }
    }

    private void step2And3_ExecuteStaffActions(WaiterAction waiterChoice, ChefAction chefChoice, HostAction hostChoice) {
        if (hostChoice != null && hostChoice.getType() == HostAction.Type.SEAT) {
            Table targetTable = getTableByNumber(hostChoice.getTableNumber());
            Customer c = waitingQueue.poll();
            targetTable.assignCustomer(c);
            c.setStatus(CustomerState.SEATED);
            host.seatExtra();
            turnEvents.add("Host seats " + c.getId() + " at Table " + targetTable.getTableNumber() + ".");
        }

        if (waiterChoice != null && waiterChoice.getType() != WaiterAction.Type.WAIT) {
            Table targetTable = getTableByNumber(waiterChoice.getTableNumber());
            switch (waiterChoice.getType()) {
                case SEAT:
                    Customer c = waitingQueue.poll();
                    targetTable.assignCustomer(c);
                    c.setStatus(CustomerState.SEATED);
                    turnEvents.add("Waiter seats " + c.getId() + " at Table " + targetTable.getTableNumber() + ".");
                    break;
                case TAKE_ORDER:
                    Customer diner = targetTable.getCustomer();
                    Order newOrder = diner.chooseFood();
                    // Price is locked now: VIP discount first, then Happy Hour, so later changes never affect it.
                    boolean happyHour = happyHourTurnsRemaining > 0;
                    newOrder.setHappyHourDiscountApplied(happyHour);
                    newOrder.lockBill(BillCalculator.calculateBill(newOrder.getBasePriceCents(), diner, happyHour));
                    targetTable.assignOrder(newOrder);
                    turnEvents.add(String.format("Waiter takes %s's order at Table %d: %s, $%.2f, %d prep units.",
                            diner.getId(), targetTable.getTableNumber(), newOrder.getName(),
                            newOrder.getBillCents() / 100.0, newOrder.getRequiredPrepUnits()));
                    break;
                case SERVE:
                    Customer served = targetTable.getCustomer();
                    served.setStatus(CustomerState.SERVED);
                    served.setServedTurn(currentTurn);
                    servedCount++;
                    turnEvents.add("Waiter serves " + served.getId() + " at Table " + targetTable.getTableNumber()
                            + "; satisfaction freezes at " + served.getSatisfaction() + ".");
                    break;
            }
            waiter.performTask();
        }

        if (chefChoice != null && chefChoice.getType() == ChefAction.Type.COOK) {
            Table targetTable = getTableByNumber(chefChoice.getTableNumber());
            Order cooked = targetTable.getOrder();
            cooked.advancePrep();
            chef.cook();
            turnEvents.add("Chef prepares Table " + targetTable.getTableNumber() + "'s " + cooked.getName() + ": "
                    + cooked.getUnitsDone() + "/" + cooked.getRequiredPrepUnits()
                    + (cooked.isReady() ? " (READY - can be served next turn)." : "."));
        }
    }

    private void step4_EatingAndPayment() {
        // A customer served on an earlier turn has finished one full turn of eating.
        for (Table t : tables) {
            if (t.isOccupied()) {
                Customer c = t.getCustomer();
                if (c.getStatus() == CustomerState.SERVED && c.getServedTurn() < currentTurn) {
                    c.setStatus(CustomerState.READY_TO_PAY);
                    c.setReadyToPayTurn(currentTurn);
                }
            }
        }

        // The Cashier pays the oldest customer who was READY_TO_PAY before this turn.
        if (cashier.isActionAvailable()) {
            Table oldest = null;
            for (Table t : tables) {
                if (!t.isOccupied()) continue;
                Customer c = t.getCustomer();
                if (c.getStatus() != CustomerState.READY_TO_PAY || c.getReadyToPayTurn() >= currentTurn) continue;
                if (oldest == null || isOlderPayer(c, oldest.getCustomer())) {
                    oldest = t;
                }
            }
            if (oldest != null) {
                Customer c = oldest.getCustomer();
                int billCents = oldest.getOrder().getBillCents();

                this.totalRevenueCents += billCents;
                c.setStatus(CustomerState.PAID);
                paidCustomers.add(c);
                turnEvents.add(String.format("Cashier collects $%.2f from %s (satisfaction %d recorded).",
                        billCents / 100.0, c.getId(), c.getSatisfaction()));

                oldest.clearTable();
                cashier.processPayment();
            }
        }
    }

    private boolean isOlderPayer(Customer candidate, Customer current) {
        if (candidate.getReadyToPayTurn() != current.getReadyToPayTurn()) {
            return candidate.getReadyToPayTurn() < current.getReadyToPayTurn();
        }
        return candidate.getArrivalTurn() < current.getArrivalTurn();
    }

    private void step5_WaitingAndAbandonment() {
        Queue<Customer> remainingQueue = new LinkedList<>();
        while (!waitingQueue.isEmpty()) {
            Customer c = waitingQueue.poll();
            c.decaySatisfaction();
            if (c.getSatisfaction() <= 0) {
                abandonedCustomers.add(c);
                turnEvents.add(c.getId() + " left the queue unhappy (satisfaction 0).");
            } else {
                remainingQueue.add(c);
            }
        }
        waitingQueue.addAll(remainingQueue);

        for (Table t : tables) {
            if (t.isOccupied()) {
                Customer c = t.getCustomer();
                if (c.getStatus() == CustomerState.WAITING || c.getStatus() == CustomerState.SEATED) {
                    c.decaySatisfaction();
                    if (c.getSatisfaction() <= 0) {
                        abandonedCustomers.add(c);
                        turnEvents.add(c.getId() + " left Table " + t.getTableNumber()
                                + " unhappy (satisfaction 0); order cancelled, no revenue.");
                        t.clearTable();
                    }
                }
            }
        }
    }

    private void step6_AdvanceTurn() {
        if (happyHourTurnsRemaining > 0) {
            happyHourTurnsRemaining--;
        }
        // Advance past MAX_TURNS so isGameOver() becomes true (capping at MAX_TURNS looped turn 18 forever).
        currentTurn++;
    }

    public boolean isGameOver() {
        return currentTurn > MAX_TURNS;
    }

    /**
     * Switches Happy Hour on at the start of a turn for this turn and the next. Allowed once per game.
     * The first turn's satisfaction recovery is applied immediately; the second is applied at the next turn start.
     */
    public void activateHappyHour() {
        if (happyHourUsed) {
            throw new InvalidGameActionException("Happy Hour can only be used once per game.");
        }
        if (happyHourTurnsRemaining > 0) {
            throw new InvalidGameActionException("Happy Hour is already active!");
        }
        this.happyHourUsed = true;
        this.happyHourTurnsRemaining = 2;
        applyHappyHourRecovery();
        turnEvents.add("Happy Hour starts: 20% off new orders and +15 satisfaction for waiting customers, for 2 turns.");
    }

    public boolean canActivateHappyHour() {
        return !happyHourUsed && happyHourTurnsRemaining == 0;
    }

    private Table getTableByNumber(int tableNumber) {
        return tables.stream()
                .filter(t -> t.getTableNumber() == tableNumber)
                .findFirst()
                .orElseThrow(() -> new InvalidGameActionException("Invalid Table Number: " + tableNumber));
    }

    private Customer spawnCustomerForTurn(int turn) {
        return CustomerFactory.createCustomerForTurn(turn);
    }

    public int getCurrentTurn() { return currentTurn; }
    public double getTotalRevenueDollars() { return totalRevenueCents / 100.0; }
    public Queue<Customer> getWaitingQueue() { return waitingQueue; }
    public List<Table> getTables() { return tables; }
    public List<Customer> getPaidCustomers() { return paidCustomers; }
    public List<Customer> getAbandonedCustomers() { return abandonedCustomers; }
    public boolean isHappyHourActive() { return happyHourTurnsRemaining > 0; }
    public int getHappyHourTurnsRemaining() { return happyHourTurnsRemaining; }

    public int getServedCount() { return servedCount; }
    public List<String> getTurnEvents() { return turnEvents; }

    /** Average satisfaction recorded when each customer paid; 0.0 when nobody has paid (display as N/A). */
    public double getAverageSatisfaction() {
        if (paidCustomers.isEmpty()) return 0.0;
        int sum = 0;
        for (Customer c : paidCustomers) {
            sum += c.getSatisfaction();
        }
        return (double) sum / paidCustomers.size();
    }

    public boolean isVictory() {
        return paidCustomers.size() >= 4 && getTotalRevenueDollars() >= 45.0 && getAverageSatisfaction() >= 60.0;
    }
}
package restaurantrush.ui;

import restaurantrush.controller.GameController;
import restaurantrush.customer.Customer;
import restaurantrush.domain.Order;
import restaurantrush.domain.Table;
import restaurantrush.exception.InvalidGameActionException;

import restaurantrush.ui.ActionEnums.WaiterAction;
import restaurantrush.ui.ActionEnums.ChefAction;
import restaurantrush.ui.ActionEnums.HostAction;

import java.util.Scanner;

/** Command-line boundary: collects the manager's choices and displays state. All rules live in the controller. */
public class RestaurantRushCLI {
    private static class InputClosedException extends RuntimeException {
        private static final long serialVersionUID = 1L;
    }

    public static void main(String[] args) {
        GameController controller = new GameController();
        Scanner scanner = new Scanner(System.in);

        System.out.println("==================================================");
        System.out.println("  WELCOME TO CT2003 RESTAURANT RUSH (STAGE 3)     ");
        System.out.println("==================================================");

        try {
            while (!controller.isGameOver()) {
                controller.startTurnStep1();
                displayStartOfTurn(controller);
                playTurn(controller, scanner);
                displayTurnEvents(controller);
            }
        } catch (InputClosedException e) {
            System.out.println("\n[Input closed - game ended early.]");
        }

        displayEndGameResults(controller);
    }

    private static void playTurn(GameController controller, Scanner scanner) {
        while (true) {
            System.out.println("\n--- ENTER MANAGER CHOICES FOR TURN " + controller.getCurrentTurn() + " ---");

            HostAction hostChoice = new HostAction(HostAction.Type.WAIT, 0);
            if (readInt(scanner, "Host Action [0: Wait, 1: Seat Customer]: ", 0, 1) == 1) {
                hostChoice = new HostAction(HostAction.Type.SEAT, readTable(scanner));
            }

            WaiterAction waiterChoice = new WaiterAction(WaiterAction.Type.WAIT, 0);
            int waiterOpt = readInt(scanner,
                    "Waiter Action [0: Wait, 1: Seat Customer, 2: Take Order, 3: Serve Order]: ", 0, 3);
            if (waiterOpt > 0) {
                WaiterAction.Type wType = WaiterAction.Type.SEAT;
                if (waiterOpt == 2) wType = WaiterAction.Type.TAKE_ORDER;
                else if (waiterOpt == 3) wType = WaiterAction.Type.SERVE;
                waiterChoice = new WaiterAction(wType, readTable(scanner));
            }

            ChefAction chefChoice = new ChefAction(ChefAction.Type.WAIT, 0);
            if (readInt(scanner, "Chef Action [0: Wait, 1: Cook Order]: ", 0, 1) == 1) {
                chefChoice = new ChefAction(ChefAction.Type.COOK, readTable(scanner));
            }

            boolean happyHour = false;
            if (controller.canActivateHappyHour()) {
                happyHour = readYesNo(scanner, "Activate Happy Hour this turn? (once per game) (y/n): ");
            }

            try {
                controller.executeRemainingSteps(waiterChoice, chefChoice, hostChoice, happyHour);
                return;
            } catch (InvalidGameActionException e) {
                // The controller validates before changing anything, so no staff task or Happy Hour was used up.
                System.out.println("\n[INVALID MOVE REJECTED]: " + e.getMessage());
                System.out.println("Nothing was used up. Please re-enter choices.");
            }
        }
    }

    private static int readTable(Scanner scanner) {
        return readInt(scanner, "Select Table (1 or 2): ", 1, 2);
    }

    /** Re-asks the same question until the answer is a whole number in range. */
    private static int readInt(Scanner scanner, String prompt, int min, int max) {
        while (true) {
            String line = readLine(scanner, prompt);
            try {
                int value = Integer.parseInt(line);
                if (value >= min && value <= max) {
                    return value;
                }
            } catch (NumberFormatException ignored) {
                // falls through to the message below
            }
            System.out.println("[ERROR]: Please enter a number from " + min + " to " + max + ".");
        }
    }

    private static boolean readYesNo(Scanner scanner, String prompt) {
        while (true) {
            String line = readLine(scanner, prompt);
            if (line.equalsIgnoreCase("y")) return true;
            if (line.equalsIgnoreCase("n")) return false;
            System.out.println("[ERROR]: Please enter y or n.");
        }
    }

    private static String readLine(Scanner scanner, String prompt) {
        System.out.print(prompt);
        if (!scanner.hasNextLine()) {
            throw new InputClosedException();
        }
        return scanner.nextLine().trim();
    }

    private static String averageText(GameController controller) {
        return controller.getPaidCustomers().isEmpty()
                ? "N/A" : String.format("%.1f", controller.getAverageSatisfaction());
    }

    private static void displayTurnEvents(GameController controller) {
        if (controller.getTurnEvents().isEmpty()) {
            return;
        }
        System.out.println("\n--- WHAT HAPPENED ---");
        for (String event : controller.getTurnEvents()) {
            System.out.println("  * " + event);
        }
    }

    private static void displayStartOfTurn(GameController controller) {
        System.out.println("\n==================================================");
        System.out.printf(" TURN %d / %d | Revenue: $%.2f | Happy Hour: %s%n",
                controller.getCurrentTurn(),
                GameController.MAX_TURNS,
                controller.getTotalRevenueDollars(),
                controller.isHappyHourActive() ? "ACTIVE (" + controller.getHappyHourTurnsRemaining() + " left)"
                        : (controller.canActivateHappyHour() ? "OFF (available)" : "USED"));
        System.out.printf(" Paid: %d | Avg Satisfaction (paid): %s | Served: %d | Unhappy departures: %d%n",
                controller.getPaidCustomers().size(),
                averageText(controller),
                controller.getServedCount(),
                controller.getAbandonedCustomers().size());
        System.out.println("==================================================");

        System.out.println("Waiting Queue (" + controller.getWaitingQueue().size() + "):");
        for (Customer c : controller.getWaitingQueue()) {
            System.out.println("  -> " + c);
        }

        System.out.println("Tables:");
        for (Table t : controller.getTables()) {
            if (!t.isOccupied()) {
                System.out.println("  Table " + t.getTableNumber() + ": [EMPTY]");
            } else {
                Customer c = t.getCustomer();
                Order o = t.getOrder();
                String orderInfo = (o == null) ? "No Order Placed" :
                        String.format("%s (Prep: %d/%d)%s", o.getName(), o.getUnitsDone(),
                                o.getRequiredPrepUnits(), o.isReady() ? " READY" : "");
                System.out.printf("  Table %d: %s | Order: %s%n", t.getTableNumber(), c, orderInfo);
            }
        }
        System.out.println("Staff available: Host (seat 1 customer), Waiter (1 task), Chef (1 prep unit), "
                + "Cashier (automatic, 1 payment)");
    }

    private static void displayEndGameResults(GameController controller) {
        System.out.println("\n==================================================");
        System.out.println("               GAME OVER RESULTS                  ");
        System.out.println("==================================================");
        System.out.printf(" Turns Used: %d / %d%n", Math.min(controller.getCurrentTurn() - 1, GameController.MAX_TURNS),
                GameController.MAX_TURNS);
        System.out.printf(" Customers Served: %d%n", controller.getServedCount());
        System.out.printf(" Total Revenue: $%.2f (Target: $45.00)%n", controller.getTotalRevenueDollars());
        System.out.printf(" Paid Customers: %d (Target: 4)%n", controller.getPaidCustomers().size());
        System.out.printf(" Average Satisfaction: %s (Target: 60.0)%n", averageText(controller));
        System.out.printf(" Unhappy Departures: %d%n", controller.getAbandonedCustomers().size());
        System.out.println("--------------------------------------------------");

        if (controller.isVictory()) {
            System.out.println(" >>> VICTORY! All targets achieved! <<<");
        } else {
            System.out.println(" >>> DEFEAT! Failed to meet target metrics. <<<");
        }
        System.out.println("==================================================");
    }
}

package restaurantrush.customer;

import restaurantrush.domain.Order;

/**
 * A restaurant customer. Subclasses supply their own satisfaction decay, bill discount and food choice,
 * so the controller never needs to check the customer type.
 */
public abstract class Customer {
    private final String id;
    private int satisfaction;
    private CustomerState status;
    private int arrivalTurn;
    private int servedTurn;
    private int readyToPayTurn;

    public Customer(String id) {
        this.id = id;
        this.satisfaction = 100;
        this.status = CustomerState.ARRIVING;
    }

    public String getId() { return id; }
    public int getSatisfaction() { return satisfaction; }
    public CustomerState getStatus() { return status; }
    public void setStatus(CustomerState status) { this.status = status; }
    public int getArrivalTurn() { return arrivalTurn; }
    public void setArrivalTurn(int arrivalTurn) { this.arrivalTurn = arrivalTurn; }
    public int getServedTurn() { return servedTurn; }
    public void setServedTurn(int servedTurn) { this.servedTurn = servedTurn; }
    public int getReadyToPayTurn() { return readyToPayTurn; }
    public void setReadyToPayTurn(int readyToPayTurn) { this.readyToPayTurn = readyToPayTurn; }

    public void decaySatisfaction() {
        if (status == CustomerState.WAITING || status == CustomerState.SEATED) {
            this.satisfaction = Math.max(0, this.satisfaction - getDecayRate());
        }
    }

    public void restoreSatisfaction(int amount) {
        if (status == CustomerState.WAITING || status == CustomerState.SEATED) {
            this.satisfaction = Math.min(100, this.satisfaction + amount);
        }
    }

    public abstract int getDecayRate();
    public abstract double getDiscountRate();
    public abstract Order chooseFood();

    @Override
    public String toString() {
        return String.format("[%s] ID: %s | Sat: %d | Status: %s", 
                getClass().getSimpleName(), id, satisfaction, status);
    }
}

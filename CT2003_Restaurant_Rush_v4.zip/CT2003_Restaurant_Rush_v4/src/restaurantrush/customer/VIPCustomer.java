package restaurantrush.customer;

import restaurantrush.domain.ComboMeal;
import restaurantrush.domain.MenuItem;
import restaurantrush.domain.Order;

/**
 * VIP: loses 5 satisfaction per waiting turn and gets 10% off the bill.
 * Order rule: a VIP always orders the Burger + Salad combo ($21.60 before the VIP discount, 2 prep units).
 */
public class VIPCustomer extends Customer {
    public VIPCustomer(String id) { super(id); }
    @Override public int getDecayRate() { return 5; }
    @Override public double getDiscountRate() { return 0.10; }
    @Override public Order chooseFood() { return new Order(new ComboMeal(MenuItem.BURGER, MenuItem.SALAD)); }
}

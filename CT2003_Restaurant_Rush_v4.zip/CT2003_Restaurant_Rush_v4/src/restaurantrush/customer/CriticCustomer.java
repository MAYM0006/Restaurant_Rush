package restaurantrush.customer;

import restaurantrush.domain.MenuItem;
import restaurantrush.domain.Order;

/**
 * Critic: loses 12 satisfaction per waiting turn and pays full price.
 * Special behaviour: a Critic is picky and always orders the quick, light Salad, so a slow
 * response from the manager is the only thing that can lose them.
 */
public class CriticCustomer extends Customer {
    public CriticCustomer(String id) { super(id); }
    @Override public int getDecayRate() { return 12; }
    @Override public double getDiscountRate() { return 0.0; }
    @Override public Order chooseFood() { return new Order(MenuItem.SALAD); }
}

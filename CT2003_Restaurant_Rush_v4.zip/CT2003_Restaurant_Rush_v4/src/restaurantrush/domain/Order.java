package restaurantrush.domain;

/**
 * One customer's order: a single menu item or a {@link ComboMeal}.
 * The bill is locked in when the order is taken, so later Happy Hour changes never affect it.
 */
public class Order {
    private final String name;
    private final int basePriceCents;
    private final int requiredPrepUnits;
    private int unitsDone;
    private boolean happyHourDiscountApplied;
    private int billCents;

    public Order(MenuItem menuItem) {
        this(menuItem.getName(), menuItem.getPriceCents(), menuItem.getRequiredPrepUnits());
    }

    public Order(ComboMeal combo) {
        this(combo.getName(), combo.getPriceCents(), combo.getRequiredPrepUnits());
    }

    private Order(String name, int basePriceCents, int requiredPrepUnits) {
        this.name = name;
        this.basePriceCents = basePriceCents;
        this.requiredPrepUnits = requiredPrepUnits;
        this.unitsDone = 0;
        this.happyHourDiscountApplied = false;
        this.billCents = basePriceCents;
    }

    public String getName() { return name; }
    public int getBasePriceCents() { return basePriceCents; }
    public int getRequiredPrepUnits() { return requiredPrepUnits; }
    public int getUnitsDone() { return unitsDone; }
    public boolean isHappyHourDiscountApplied() { return happyHourDiscountApplied; }
    public void setHappyHourDiscountApplied(boolean applied) { this.happyHourDiscountApplied = applied; }
    public int getBillCents() { return billCents; }
    public void lockBill(int billCents) { this.billCents = billCents; }

    public void advancePrep() {
        if (!isReady()) {
            this.unitsDone++;
        }
    }

    public boolean isReady() {
        return unitsDone >= requiredPrepUnits;
    }
}

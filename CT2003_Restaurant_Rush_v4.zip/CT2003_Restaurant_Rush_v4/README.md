# CT2003 Restaurant Rush - v4 (Stage 3)

A turn-based restaurant management game in Java with a command-line interface. You are the manager:
each turn you choose what the Host, Waiter and Chef do. This is the full Stage 3 game (Host, ComboMeal,
Happy Hour, VIP and Critic customers) and the base setting from the assignment brief.

## Requirements

A **JDK 9 or newer** (the code uses `List.of`). A JRE alone cannot compile it.

## Run

Windows: double-click or run `run.bat`.
Mac/Linux/Git Bash: `bash run.sh`.

Both compile into `build/` and start the game. Delete `build/` first if you have old compiled classes.

## How to play

Each turn the screen shows the turn number, revenue, average satisfaction of paid customers, served count,
unhappy departures, the waiting queue, both tables (with order progress, `READY` when cooked) and the staff
available. Then answer the prompts:

| Prompt | Choices |
|---|---|
| Host | 0 Wait, 1 Seat the next queued customer (then pick table 1 or 2) |
| Waiter (one task per turn) | 0 Wait, 1 Seat, 2 Take Order, 3 Serve Order (then pick table) |
| Chef (one prep unit per turn) | 0 Wait, 1 Cook Order (then pick table) |
| Happy Hour | y/n, only shown while it is still available (once per game) |

Invalid input is re-asked. An invalid move (for example serving a dish that is not READY) is rejected with
the reason, nothing is used up, and you choose again. After each turn a "WHAT HAPPENED" list shows seating,
orders (with the dish chosen and price), cooking progress, serving, payments and walk-outs.

A turn runs in this order: arrivals, manager choices, kitchen and serving, eating and payment, waiting and
abandonment, advance. The game always runs all 18 turns, then shows Victory or Defeat.

**Win:** at least 4 paid customers AND revenue of at least $45.00 AND average satisfaction of paid
customers of at least 60. The average shows `N/A` until someone has paid.

## Rules

| Item | Rule |
|---|---|
| Arrivals | Turns 1, 4, 7, 10, 13, 16. Turn 7 is a VIP, turn 13 is a Critic, the rest are Regular |
| Satisfaction loss per turn waiting or seated, not yet served | Regular 8, VIP 5, Critic 12. Reaching 0 means the customer leaves, the order is cancelled and the table is freed |
| Serving | A dish can be served only if it was already READY before the Waiter acts. A dish finished this turn is served next turn at the earliest |
| Payment | Served on turn T, READY_TO_PAY on T+1, paid on T+2. The Cashier pays at most one customer per turn, oldest first |
| VIP bill | 10% off |
| Happy Hour | Once per game, lasts the turn it starts and the next. Orders taken while it is active get 20% off (VIP discount first, then Happy Hour). The price is locked when the order is taken. Waiting or seated customers recover 15 satisfaction (max 100) on each of the two turns |
| Host | Seats at most one queued customer per turn, in addition to the Waiter's task |
| Money | Stored as integer cents, shown as dollars with two decimals |

### What each customer orders

Customers choose their own food by a fixed rule, so runs are reproducible. The choice is shown when the order is taken.

| Customer | Order | Price | Prep units |
|---|---|---|---|
| Regular | Pasta | $18.00 | 2 |
| VIP | Burger + Salad combo (10% off the $24.00 total = $21.60, then the VIP's 10% off = $19.44) | $19.44 | 2 |
| Critic | Salad | $9.00 | 1 |

A combo costs 90% of its two items' combined price and needs the sum of their prep units
(for example Salad + Pasta = $24.30, 3 units).

## Test runs (reproducible)

The game is deterministic, so a text file of answers replays the same game. From this folder, after
compiling (see Run):

```
cmd /c "java -cp build restaurantrush.ui.RestaurantRushCLI < test_runs\victory.txt"
```

| Script | Result |
|---|---|
| `test_runs/victory.txt` | VICTORY: 5 paid, $82.44, average satisfaction 86.0 |
| `test_runs/victory_happy_hour.txt` | VICTORY with Happy Hour on turn 7: 5 paid, $78.55, average 87.0 |
| `test_runs/defeat.txt` | DEFEAT: a slow manager. Turns 1-9 run like the victory run (3 customers paid, $55.44, average satisfaction 86.0), then the manager idles for turns 10-14 and seats the remaining customers too late. The last customers are served on turns 17 and 18 and cannot pay in time, so only 3 customers pay. Revenue and satisfaction targets are met; the paid-customers target (4) is missed |

On Mac/Linux use `java -cp build restaurantrush.ui.RestaurantRushCLI < test_runs/victory.txt`.

## Automated rule checks

`test.bat` (or `bash test.sh`) compiles and runs `tests/RuleChecks.java`, a plain-Java check suite (no
libraries needed). It covers combo and discount pricing, payment timing, re-serving, Happy Hour (not used up
by a rejected turn, once per game, no discount on older orders, recovery on both turns) and rejected moves.
It prints `ALL CHECKS PASSED` or exits with an error.

## Project layout

```
src/restaurantrush/
  controller/GameController   all game rules and the turn sequence (the only place rules live)
  customer/                   Customer (abstract), RegularCustomer, VIPCustomer, CriticCustomer, CustomerFactory, CustomerState
  domain/                     Table, Order, MenuItem, ComboMeal, BillCalculator
  staff/                      Staff (abstract), Waiter, Chef, Host, Cashier
  ui/                         RestaurantRushCLI (input/output only), ActionEnums
  exception/                  InvalidGameActionException
tests/RuleChecks.java         automated rule checks
test_runs/                    scripted victory and defeat runs
```

## Changes in v4 compared with v3

v3 was the Stage 3 code as handed over. v4 aligns it with the brief's rules. Everything below was found by
comparing the code with the brief and with the Stage 1 and Stage 2 versions.

**Bugs fixed**
- **The game never ended.** The turn counter stopped at 18 while the CLI looped until it passed 18, so turn 18
  repeated forever and the results were never shown. The counter now advances past 18 and
  `GameController.isGameOver()` ends the loop.
- **Happy Hour was used up by a rejected turn.** The CLI switched it on before the controller validated the
  turn. It is now requested through `executeRemainingSteps(..., activateHappyHour)` and only starts once the
  whole turn has been validated.
- **Re-serving.** A table that was already served could be served again, which pushed payment back. It is now rejected.
- **Closed or piped input** looped forever printing errors. The game now ends cleanly.
- **Unknown table numbers** for the Host are rejected during validation, before anything changes.

**Rules brought in line with the brief**
- Payment now happens on T+2 after serving (it was T+1), and the Cashier pays the oldest customer first
  (it was table 1 first). `Customer` now records `arrivalTurn`, `servedTurn` and `readyToPayTurn`.
- Happy Hour: once per game (it could be restarted after expiring); only discounts orders taken while it is
  active (it also discounted older orders if they were paid during it); recovery now applies on both of its
  turns (it applied on one). `Order` now locks its bill when the order is taken.
- `ComboMeal` is now used: `Order` holds a name, price and prep units, so it can be a menu item or a combo, and the
  VIP orders the Burger + Salad combo.
- Display: average satisfaction shows `N/A` before anyone has paid; the turn header shows served count and unhappy
  departures; a staff-available line; a game-over summary with turns used and customers served; an order shows
  `READY` when cooked; a per-turn "WHAT HAPPENED" log.
- Input: each prompt re-asks on bad input instead of restarting the whole turn, and the generic catch-all was removed.
- Javadoc added to the customer classes, with the Regular, VIP and Critic order rules documented.

**Added**
- `test_runs/` scripted runs and `tests/RuleChecks.java` with `test.bat` / `test.sh`.


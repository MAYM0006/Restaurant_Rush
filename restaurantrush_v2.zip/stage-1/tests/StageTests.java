package restaurantrush.sim;

import java.util.List;

/** Zero-dependency regression checks; run with java -ea -cp build restaurantrush.sim.StageTests. */
public final class StageTests {
    private static int checks;
    private static void check(boolean ok, String message) {
        checks++;
        if (!ok) throw new AssertionError(message);
    }
    private static void turn(Night n, Waiter.Action w, Chef.Action c) {
        n.startTurn();
        n.act(w, c);
    }
    private static void waitTurn(Night n) { turn(n, Waiter.Action.waitAction(), Chef.Action.waitAction()); }
    private static Guest find(Night n, String name) {
        return n.customers().stream().filter(c -> c.name().equals(name)).findFirst().orElseThrow();
    }

    private static void arrivalAndBaseSettings() {
        Night n = Night.opening();
        check(n.tables().size() == 2, "Exactly two tables");
        check(n.tables().stream().allMatch(t -> !t.isOccupied()), "Tables start empty");
        for (int t=1; t<=18; t++) {
            n.startTurn();
            int expected = t<=16 && (t-1)%3 == 0 ? 1 : 0;
            check(n.events().size() == expected, "Arrival count at turn " + t);
            n.act(Waiter.Action.waitAction(), Chef.Action.waitAction());
        }
        check(n.customers().size() == 6, "Exactly six arrivals");
        check(!n.victory(), "No-service run must fail");
        check(n.unhappyDepartures() >= 1, "Waiting customers abandon at zero");
    }

    private static void servingPaymentTimeline() {
        Night n = Night.opening();
        turn(n, Waiter.Action.seat("Ari",1), Chef.Action.waitAction());
        check(find(n,"Ari").satisfaction()==92,"Turn 1 decay");
        turn(n, Waiter.Action.order("Ari"), Chef.Action.prepare("Ari"));
        check(find(n,"Ari").order().isReady(), "Salad READY at turn 2");
        check(find(n,"Ari").satisfaction()==84, "Turn 2 decay");
        check(n.paidCount()==0, "Not prematurely paid");
        turn(n, Waiter.Action.serve("Ari"), Chef.Action.waitAction());
        check(find(n,"Ari").phase() == Guest.Phase.SERVED, "SERVED on turn 3");
        check(find(n,"Ari").satisfaction()==84, "Satisfaction frozen at service");
        waitTurn(n);
        check(find(n,"Ari").phase() == Guest.Phase.READY_TO_PAY, "Full eating turn before payment");
        check(n.paidCount()==0,"Cannot pay on newly-ready turn");
        waitTurn(n);
        check(n.paidCount()==1,"Pays next turn");
        check(n.revenueCents()==900,"Base price without tips");
        check(find(n,"Ari").paidSatisfaction()==84,"Records paid satisfaction");
        check(!n.tables().get(0).isOccupied(),"Frees table at payment");
        check(find(n,"Ari").order().orderStatus()==OrderStatus.PAID,"Order PAID");
    }

    private static void invalidActionRetryAndPrepLimit() {
        Night n = Night.opening();
        n.startTurn();
        boolean rejected = false;
        try { n.act(Waiter.Action.order("Ari"), Chef.Action.waitAction()); }
        catch (IllegalArgumentException ex) { rejected = true; }
        check(rejected && n.currentTurn()==1 && n.awaitingActions(), "Invalid choice does not consume turn");
        n.act(Waiter.Action.seat("Ari",1), Chef.Action.waitAction());
        n.startTurn();
        rejected = false;
        try { n.act(Waiter.Action.waitAction(), Chef.Action.prepare("Ari")); }
        catch (IllegalArgumentException ex) { rejected = true; }
        check(rejected && n.awaitingActions(),"Cannot cook without taking order");
        n.act(Waiter.Action.order("Ari"), Chef.Action.prepare("Ari"));
        check(find(n,"Ari").order().unitsDone()==1, "Chef does exactly one unit");
        n.startTurn();
        rejected=false;
        try { n.act(Waiter.Action.waitAction(), Chef.Action.prepare("Ari")); }
        catch (IllegalArgumentException ex) { rejected=true; }
        check(rejected && n.awaitingActions(),"Cannot cook READY order again");
        n.act(Waiter.Action.serve("Ari"), Chef.Action.waitAction());
    }

    private static void abandonmentAndCancelledOrder() {
        Night n=Night.opening();
        turn(n,Waiter.Action.seat("Ari",1),Chef.Action.waitAction());
        turn(n,Waiter.Action.order("Ari"),Chef.Action.waitAction());
        for(int i=3;i<=13;i++) waitTurn(n);
        Guest c=find(n,"Ari");
        check(c.phase()==Guest.Phase.LEFT,"Seated customer abandons at zero");
        check(c.order()!=null && c.order().orderStatus()==OrderStatus.CANCELLED,"Unfinished order cancelled");
        check(!n.tables().get(0).isOccupied(),"Table freed on abandonment");
        check(n.revenueCents()==0,"Abandoned order never paid");
        check(n.unhappyDepartures()>=1,"Reports unhappy departure");
    }

    private static void legalTurn18Payment() {
        Night n=Night.opening();
        for(int t=1;t<=12;t++) waitTurn(n);
        turn(n,Waiter.Action.seat("Eli",1),Chef.Action.waitAction()); // T13
        turn(n,Waiter.Action.order("Eli"),Chef.Action.prepare("Eli")); // T14, menu first = Salad
        waitTurn(n); // T15, order READY
        turn(n,Waiter.Action.serve("Eli"),Chef.Action.waitAction()); // T16
        waitTurn(n); // T17, ready to pay
        check(n.paidCount()==0,"Not paid before T18");
        waitTurn(n); // T18
        check(find(n,"Eli").phase()==Guest.Phase.PAID,"Cashier pays on turn 18");
    }

    private static void requiresAllVictoryConditions() {
        Night n=Night.opening();
        Waiter.Action[] waiter = {
            Waiter.Action.seat("Ari",1), Waiter.Action.order("Ari"), Waiter.Action.serve("Ari"),
            Waiter.Action.seat("Blair",2), Waiter.Action.order("Blair"), Waiter.Action.serve("Blair"),
            Waiter.Action.seat("Chen",1), Waiter.Action.order("Chen"), Waiter.Action.waitAction(),
            Waiter.Action.serve("Chen"), Waiter.Action.seat("Dina",2), Waiter.Action.order("Dina"),
            Waiter.Action.serve("Dina")
        };
        Chef.Action[] chef={
            Chef.Action.waitAction(),Chef.Action.prepare("Ari"),Chef.Action.waitAction(),
            Chef.Action.waitAction(),Chef.Action.prepare("Blair"),Chef.Action.waitAction(),
            Chef.Action.waitAction(),Chef.Action.prepare("Chen"),Chef.Action.prepare("Chen"),
            Chef.Action.waitAction(),Chef.Action.waitAction(),Chef.Action.prepare("Dina"),
            Chef.Action.waitAction()
        };
        for(int i=0;i<18;i++) {
            if(i<waiter.length) turn(n,waiter[i],chef[i]); else waitTurn(n);
        }
        check(n.paidCount()==4,"Victory trace has four paid customers");
        check(n.revenueCents()==5100,"Victory trace reaches $51");
        check(n.averagePaidSatisfaction()>=60,"Victory trace average >= 60");
        check(n.victory(),"Victory requires all three conditions");
    }

    private static void victoryRequiresAllThreeTargets() {
        okTargets(Night.meetsVictoryTargets(4,4500,60.0), "All victory thresholds satisfied");
        okTargets(!Night.meetsVictoryTargets(3,4500,60.0), "Three payments are insufficient");
        okTargets(!Night.meetsVictoryTargets(4,4499,60.0), "Revenue below $45 is insufficient");
        okTargets(!Night.meetsVictoryTargets(4,4500,59.99), "Paid average below 60 is insufficient");
        okTargets(!Night.meetsVictoryTargets(4,4500,Double.NaN), "No paid satisfaction does not imply victory");
    }

    private static void okTargets(boolean result, String message) {
        checks++;
        if (!result) throw new AssertionError(message);
    }

    public static void main(String[] args) {
        victoryRequiresAllThreeTargets();
        arrivalAndBaseSettings();
        servingPaymentTimeline();
        invalidActionRetryAndPrepLimit();
        abandonmentAndCancelledOrder();
        legalTurn18Payment();
        requiresAllVictoryConditions();
        System.out.println("PASS Stage 1 checks: " + checks);
    }
}

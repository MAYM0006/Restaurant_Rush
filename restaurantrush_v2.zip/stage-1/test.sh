#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p build
javac --release 17 -d build $(find src tests -name '*.java')
java -ea -cp build restaurantrush.sim.StageTests

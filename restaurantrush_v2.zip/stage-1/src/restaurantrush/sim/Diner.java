package restaurantrush.sim;

import java.util.Locale;

/** Console command parser; domain rules remain in Night and entity objects. */
public final class Diner {
    private Diner() {}

    public record Choice(Waiter.Action waiter, Chef.Action chef) {}

    /** Format: "seat Ari 1 | wait", "order Ari | prep Ari", "serve Ari | wait". */
    public static Choice parse(String line) {
        String[] parts = line == null ? new String[0] : line.trim().split("\\|", -1);
        if (parts.length != 2)
            throw new IllegalArgumentException("Use 'WAITER ACTION | CHEF ACTION' (e.g. seat Ari 1 | wait).");
        return new Choice(waiter(parts[0].trim()), chef(parts[1].trim()));
    }

    static Waiter.Action waiter(String command) {
        String[] tokens = command.trim().split("\\s+");
        String action = tokens[0].toLowerCase(Locale.ROOT);
        switch (action) {
            case "wait" -> { if (tokens.length == 1) return Waiter.Action.waitAction(); }
            case "seat" -> {
                if (tokens.length == 3) {
                    try { return Waiter.Action.seat(tokens[1], Integer.parseInt(tokens[2])); }
                    catch (NumberFormatException ignored) { }
                }
            }
            case "order" -> { if (tokens.length == 2) return Waiter.Action.order(tokens[1]); }
            case "serve" -> { if (tokens.length == 2) return Waiter.Action.serve(tokens[1]); }
            default -> { }
        }
        throw new IllegalArgumentException("Waiter action: wait, seat NAME TABLE, order NAME, or serve NAME.");
    }

    static Chef.Action chef(String command) {
        String[] tokens = command.trim().split("\\s+");
        String action = tokens[0].toLowerCase(Locale.ROOT);
        if (tokens.length == 1 && action.equals("wait")) return Chef.Action.waitAction();
        if (tokens.length == 2 && action.equals("prep")) return Chef.Action.prepare(tokens[1]);
        throw new IllegalArgumentException("Chef action: wait or prep NAME.");
    }
}

package restaurantrush.sim;

import java.util.ArrayList;
import java.util.List;

/** Six deterministic arrivals at turns 1, 4, 7, 10, 13, and 16. */
public final class Guests {
    private Guests() {}
    private static final String[] NAMES = { "Ari", "Blair", "Chen", "Dina", "Eli", "Farah" };
    public static List<Guest> arriving(int turn) {
        List<Guest> result = new ArrayList<>();
        if (turn >= 1 && turn <= 16 && (turn - 1) % 3 == 0) {
            result.add(new RegularCustomer(NAMES[(turn - 1) / 3]));
        }
        return result;
    }
}

package restaurantrush.sim;

/** The manager chooses one order to advance by one preparation unit. */
public final class Chef {
    public record Action(String customer) {
        public static Action waitAction() { return new Action(""); }
        public static Action prepare(String customer) { return new Action(customer); }
        public boolean isWait() { return customer == null || customer.isEmpty(); }
    }
    private Chef() {}
}

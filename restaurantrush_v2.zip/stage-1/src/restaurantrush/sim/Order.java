package restaurantrush.sim;

import restaurantrush.entity.Money;

/** Owns preparation, serving, payment and abandonment transitions. */
public final class Order {
    private final Dish item;
    private final int priceCents;
    private int unitsDone;
    private OrderStatus orderStatus = OrderStatus.PREPARING;

    public Order(Dish item, int keepPercent) {
        if (item == null || keepPercent < 0 || keepPercent > 100)
            throw new IllegalArgumentException("Invalid order configuration.");
        this.item = item;
        this.priceCents = Money.keepPercent(item.priceCents, keepPercent);
    }

    public Dish item() { return item; }
    public int priceCents() { return priceCents; }
    public int unitsDone() { return unitsDone; }
    public int requiredUnits() { return item.prepUnits; }
    public OrderStatus orderStatus() { return orderStatus; }
    public boolean isReady() { return orderStatus == OrderStatus.READY; }

    public void advancePrep() {
        require(OrderStatus.PREPARING);
        unitsDone++;
        if (unitsDone == item.prepUnits) orderStatus = OrderStatus.READY;
    }

    public void serve() { require(OrderStatus.READY); orderStatus = OrderStatus.SERVED; }
    public void pay() { require(OrderStatus.SERVED); orderStatus = OrderStatus.PAID; }

    public void cancel() {
        if (orderStatus != OrderStatus.PREPARING && orderStatus != OrderStatus.READY)
            throw new IllegalStateException("Only unfinished orders can be cancelled.");
        orderStatus = OrderStatus.CANCELLED;
    }

    private void require(OrderStatus expected) {
        if (orderStatus != expected) throw new IllegalStateException(
            "Order must be " + expected + ", but is " + orderStatus + ".");
    }
}

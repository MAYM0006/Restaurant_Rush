package restaurantrush.sim;

import java.util.Comparator;
import java.util.List;

/** Automatically pays at most one customer who was ready before the current turn. */
public final class Cashier {
    private Cashier() {}
    public static Guest oldestEligible(List<Guest> guests, int currentTurn) {
        return guests.stream()
            .filter(g -> g.phase() == Guest.Phase.READY_TO_PAY && g.readyTurn() < currentTurn)
            .min(Comparator.comparingInt(Guest::readyTurn))
            .orElse(null);
    }
}

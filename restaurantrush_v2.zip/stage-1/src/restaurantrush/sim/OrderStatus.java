package restaurantrush.sim;

/** The Order state machine is distinct from the customer lifecycle. */
public enum OrderStatus { PREPARING, READY, SERVED, PAID, CANCELLED }

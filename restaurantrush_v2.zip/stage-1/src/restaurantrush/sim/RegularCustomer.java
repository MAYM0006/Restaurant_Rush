package restaurantrush.sim;

/** Stage 1 customer. Fixed behaviour is overridden polymorphically in Stage 2. */
public final class RegularCustomer extends Guest {
    public RegularCustomer(String name) { super(name); }
    @Override public int decayRate() { return 8; }
    @Override public String kind() { return "Regular"; }
    @Override public Dish chooseFood(FoodMenu menu, int ordinal) { return menu.get(ordinal); }
}

package restaurantrush.sim;

/** Each table accommodates exactly one customer, and is freed on payment or departure. */
public final class Table {
    private final int number;
    private Guest occupant;
    public Table(int number) { this.number = number; }
    public int number() { return number; }
    public Guest occupant() { return occupant; }
    public boolean isOccupied() { return occupant != null; }
    public void assignCustomer(Guest guest) {
        if (isOccupied()) throw new IllegalStateException("Table " + number + " is occupied.");
        if (guest == null) throw new IllegalArgumentException("Customer is required.");
        guest.seat(number);
        occupant = guest;
    }
    public void clear() { occupant = null; }
}

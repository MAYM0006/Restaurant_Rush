package restaurantrush.sim;

/** One manager-directed waiter action is allowed per turn. */
public final class Waiter {
    public enum Task { WAIT, SEAT, TAKE_ORDER, SERVE }
    public record Action(Task task, String customer, int table) {
        public static Action waitAction() { return new Action(Task.WAIT, "", 0); }
        public static Action seat(String who, int table) { return new Action(Task.SEAT, who, table); }
        public static Action order(String who) { return new Action(Task.TAKE_ORDER, who, 0); }
        public static Action serve(String who) { return new Action(Task.SERVE, who, 0); }
    }
    private Waiter() {}
}

package restaurantrush.sim;

import java.util.ArrayList;
import java.util.List;
import restaurantrush.entity.Money;

/** One discrete 18-turn shift. This replaces the prior elapsed-millisecond simulation. */
public final class Night {
    public static final int TURN_COUNT = 18;
    private final FoodMenu menu;
    private final List<Guest> customers = new ArrayList<>();
    private final List<Table> tables = List.of(new Table(1), new Table(2));
    private final List<String> events = new ArrayList<>();
    private int currentTurn;
    private int revenueCents;
    private int servedCount;
    private int unhappyDepartures;
    private int orderOrdinal;
    private boolean awaitingActions;

    public Night(FoodMenu menu) { this.menu = menu; }
    public static Night opening() { return new Night(FoodMenu.opening()); }
    public int currentTurn() { return currentTurn; }
    public int revenueCents() { return revenueCents; }
    public int servedCount() { return servedCount; }
    public int unhappyDepartures() { return unhappyDepartures; }
    public List<Guest> customers() { return List.copyOf(customers); }
    public List<Table> tables() { return tables; }
    public List<String> events() { return List.copyOf(events); }
    public boolean awaitingActions() { return awaitingActions; }

    public int paidCount() {
        int result = 0;
        for (Guest c : customers) if (c.phase() == Guest.Phase.PAID) result++;
        return result;
    }

    public double averagePaidSatisfaction() {
        int total = 0;
        for (Guest c : customers) if (c.phase() == Guest.Phase.PAID) total += c.paidSatisfaction();
        return paidCount() == 0 ? Double.NaN : (double) total / paidCount();
    }

    /** Pure outcome rule, including the average paid-customer satisfaction threshold. */
    public static boolean meetsVictoryTargets(int paid, int revenueCents, double averagePaidSatisfaction) {
        return paid >= 4 && revenueCents >= 4500 && averagePaidSatisfaction >= 60.0;
    }

    public boolean victory() {
        return currentTurn == TURN_COUNT && !awaitingActions
            && meetsVictoryTargets(paidCount(), revenueCents, averagePaidSatisfaction());
    }

    public void startTurn() {
        if (awaitingActions) throw new IllegalStateException("Finish the current turn first.");
        if (currentTurn >= TURN_COUNT) throw new IllegalStateException("All 18 turns are complete.");
        currentTurn++;
        awaitingActions = true;
        events.clear();
        for (Guest customer : Guests.arriving(currentTurn)) {
            customers.add(customer);
            events.add(customer.name() + " arrives (" + customer.kind() + ", satisfaction 100).");
        }
    }

    /** Invalid actions are rejected before any game state is changed. */
    public void act(Waiter.Action waiter, Chef.Action chef) {
        if (!awaitingActions) throw new IllegalStateException("Start a turn before choosing actions.");
        if (waiter == null || chef == null) throw new IllegalArgumentException("Both staff choices are required.");
        validateWaiter(waiter);
        validateChef(chef, waiter);
        performWaiter(waiter);
        performChef(chef);
        payOldestEligible();
        for (Guest customer : customers) customer.advanceEating(currentTurn);
        for (Guest customer : customers) {
            if (customer.decay()) {
                unhappyDepartures++;
                freeTable(customer);
                events.add(customer.name() + " abandoned at satisfaction 0; unfinished order cancelled, no revenue.");
            }
        }
        awaitingActions = false;
        if (currentTurn == TURN_COUNT)
            events.add(victory() ? "VICTORY" : "DEFEAT");
    }

    private Guest find(String name) {
        if (name == null) throw new IllegalArgumentException("Customer name required.");
        for (Guest c : customers) if (c.name().equalsIgnoreCase(name)) return c;
        throw new IllegalArgumentException("Customer not found: " + name);
    }

    private Table table(int number) {
        if (number < 1 || number > tables.size()) throw new IllegalArgumentException("Table must be 1 or 2.");
        return tables.get(number - 1);
    }

    private void validateWaiter(Waiter.Action choice) {
        switch (choice.task()) {
            case WAIT -> {}
            case SEAT -> {
                Guest c = find(choice.customer());
                if (c.phase() != Guest.Phase.WAITING) throw new IllegalArgumentException("Customer is not waiting.");
                if (table(choice.table()).isOccupied()) throw new IllegalArgumentException("Table is occupied.");
            }
            case TAKE_ORDER -> {
                Guest c = find(choice.customer());
                if (c.phase() != Guest.Phase.SEATED || c.order() != null)
                    throw new IllegalArgumentException("Customer must be seated and not yet ordered.");
            }
            case SERVE -> {
                Guest c = find(choice.customer());
                if (c.phase() != Guest.Phase.SEATED || c.order() == null || !c.order().isReady())
                    throw new IllegalArgumentException("Customer must have a READY order from an earlier turn.");
            }
        }
    }

    private void validateChef(Chef.Action chef, Waiter.Action waiter) {
        if (chef.isWait()) return;
        Guest c = find(chef.customer());
        if (c.phase() != Guest.Phase.SEATED)
            throw new IllegalArgumentException("Chef can prepare only a seated customer's order.");
        if (c.order() != null && c.order().orderStatus() == OrderStatus.PREPARING) return;
        if (c.order() == null && waiter.task() == Waiter.Task.TAKE_ORDER
                && c.name().equalsIgnoreCase(waiter.customer())) return;
        throw new IllegalArgumentException("Chef can prepare only an existing PREPARING order, or one taken this turn.");
    }

    private void performWaiter(Waiter.Action waiter) {
        switch (waiter.task()) {
            case WAIT -> events.add("Waiter waits.");
            case SEAT -> {
                Guest c = find(waiter.customer());
                table(waiter.table()).assignCustomer(c);
                events.add("Waiter seats " + c.name() + " at Table " + waiter.table() + ".");
            }
            case TAKE_ORDER -> {
                Guest c = find(waiter.customer());
                Dish chosen = c.chooseFood(menu, orderOrdinal++);
                c.takeOrder(chosen);
                events.add("Waiter takes " + c.name() + "'s order: " + chosen.name
                    + ", " + Money.dollars(c.order().priceCents()) + ", " + chosen.prepUnits + " prep units.");
            }
            case SERVE -> {
                Guest c = find(waiter.customer());
                c.serve(currentTurn);
                servedCount++;
                events.add("Waiter serves " + c.name() + "; satisfaction freezes at " + c.satisfaction() + ".");
            }
        }
    }

    private void performChef(Chef.Action chef) {
        if (chef.isWait()) { events.add("Chef waits."); return; }
        Guest c = find(chef.customer());
        Order o = c.order();
        o.advancePrep();
        events.add("Chef prepares " + c.name() + "'s order: " + o.unitsDone() + "/"
            + o.requiredUnits() + (o.isReady() ? " (READY for a later turn)." : "."));
    }

    private void payOldestEligible() {
        Guest c = Cashier.oldestEligible(customers, currentTurn);
        if (c == null) return;
        c.pay(currentTurn);
        revenueCents += c.order().priceCents();
        freeTable(c);
        events.add("Cashier collects " + Money.dollars(c.order().priceCents()) + " from "
            + c.name() + " (satisfaction " + c.paidSatisfaction() + ").");
    }

    private void freeTable(Guest c) {
        for (Table t : tables) if (t.occupant() == c) t.clear();
    }

    public String report() {
        StringBuilder s = new StringBuilder();
        s.append("Turn ").append(currentTurn).append("/18 | Revenue ").append(Money.dollars(revenueCents))
            .append(" | Paid ").append(paidCount()).append(" | Avg paid satisfaction ");
        s.append(paidCount() == 0 ? "N/A" : String.format(java.util.Locale.ROOT, "%.1f", averagePaidSatisfaction()));
        s.append(" | Served ").append(servedCount).append(" | Unhappy departures ").append(unhappyDepartures).append('\n');
        s.append("Waiting queue: ");
        boolean any = false;
        for (Guest c : customers) if (c.phase() == Guest.Phase.WAITING) {
            if (any) s.append(", ");
            s.append(c.name()); any = true;
        }
        if (!any) s.append("(empty)");
        s.append('\n');
        for (Table t : tables) s.append("Table ").append(t.number()).append(": ")
            .append(t.occupant() == null ? "free" : t.occupant().name()).append('\n');
        for (Guest c : customers) {
            s.append(c.name()).append(" [").append(c.kind()).append("] ")
                .append(c.phase()).append(" satisfaction=").append(c.satisfaction());
            if (c.order() != null) s.append(" order=").append(c.order().orderStatus())
                .append(" ").append(c.order().unitsDone()).append("/").append(c.order().requiredUnits());
            s.append('\n');
        }
        s.append("Staff available: Waiter (1 action), Chef (1 prep unit), Cashier (automatic 1 payment).\n");
        return s.toString();
    }
}

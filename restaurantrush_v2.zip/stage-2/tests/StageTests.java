package restaurantrush.sim;

/** Stage 1 rules plus Stage 2 polymorphism and discount regression checks. */
public final class StageTests {
    private static int checks;
    private static void ok(boolean b, String message) { checks++; if (!b) throw new AssertionError(message); }
    private static Guest find(Night n, String name) {
        return n.customers().stream().filter(x -> x.name().equals(name)).findFirst().orElseThrow();
    }
    private static void play(Night n, Waiter.Action w, Chef.Action c) {
        n.startTurn(); n.act(w,c);
    }
    private static void waitTurn(Night n) { play(n, Waiter.Action.waitAction(), Chef.Action.waitAction()); }

    private static void polymorphism() {
        FoodMenu menu=FoodMenu.opening();
        Guest regular=new RegularCustomer("Regular"), vip=new VIPCustomer("VIP"), critic=new CriticCustomer("Critic");
        ok(regular.decayRate()==8 && vip.decayRate()==5 && critic.decayRate()==12,"Polymorphic satisfaction decay rates");
        regular.decay(); vip.decay(); critic.decay();
        ok(regular.satisfaction()==92 && vip.satisfaction()==95 && critic.satisfaction()==88,"Actual decay behaviour");
        ok(vip.priceKeepPercent()==90 && critic.priceKeepPercent()==100,"VIP discount, Critic full price");
        ok(vip.chooseFood(menu,0).name.equals("Pasta"),"VIP prefers highest-priced dish");
        ok(critic.chooseFood(menu,0).name.equals("Pasta"),"Critic prefers longest-preparation dish");
        ok(regular.chooseFood(menu,0).name.equals("Salad"),"Regular chooses deterministically");
        ok(new Order(vip.chooseFood(menu,0), vip.priceKeepPercent()).priceCents()==1620,"VIP Pasta is $16.20");
    }

    private static void arrivalsAndFlow() {
        Night n=Night.opening();
        for(int t=1;t<=18;t++) {
            n.startTurn();
            if(t==1) n.act(Waiter.Action.seat("Ari",1),Chef.Action.waitAction());
            else if(t==2) n.act(Waiter.Action.order("Ari"),Chef.Action.prepare("Ari"));
            else if(t==3) n.act(Waiter.Action.serve("Ari"),Chef.Action.waitAction());
            else n.act(Waiter.Action.waitAction(),Chef.Action.waitAction());
        }
        ok(n.customers().size()==6,"Six arrivals");
        ok(find(n,"Blair") instanceof VIPCustomer,"VIP included in reproducible base run");
        ok(find(n,"Dina") instanceof CriticCustomer,"Critic included in reproducible base run");
        ok(find(n,"Ari").phase()==Guest.Phase.PAID && n.revenueCents()==900,"Base lifecycle still works");
        ok(find(n,"Blair").phase()==Guest.Phase.WAITING,"VIP not prematurely abandoned");
        ok(n.currentTurn()==18,"All turns execute");
    }

    private static void stage2Victory() {
        Night n=Night.opening();
        String[] turns={
            "seat Ari 1 | wait","order Ari | prep Ari","serve Ari | wait",
            "seat Blair 2 | wait","order Blair | prep Blair","wait | prep Blair","serve Blair | wait",
            "seat Chen 1 | wait","order Chen | prep Chen","seat Dina 2 | prep Chen",
            "serve Chen | wait","order Dina | prep Dina","wait | prep Dina","serve Dina | wait",
            "wait | wait","wait | wait","wait | wait","wait | wait"
        };
        for(String s:turns) { Diner.Choice c=Diner.parse(s); play(n,c.waiter(),c.chef()); }
        ok(n.paidCount()==4,"Stage 2 trace paid four customers");
        ok(n.revenueCents()==6120,"Stage 2 trace price includes VIP discount");
        ok(n.averagePaidSatisfaction()>=60,"Stage 2 trace satisfies satisfaction");
        ok(n.victory(),"Stage 2 victory");
    }

    private static void invalidsRemainAtomic() {
        Night n=Night.opening(); n.startTurn();
        boolean thrown=false;
        try { n.act(Waiter.Action.order("Ari"),Chef.Action.prepare("Ari")); }
        catch(IllegalArgumentException ex) { thrown=true; }
        ok(thrown && n.currentTurn()==1 && n.awaitingActions(),"No turn lost on invalid action");
        n.act(Waiter.Action.seat("Ari",1),Chef.Action.waitAction());
    }

    private static void victoryRequiresAllThreeTargets() {
        okTargets(Night.meetsVictoryTargets(4,4500,60.0), "All victory thresholds satisfied");
        okTargets(!Night.meetsVictoryTargets(3,4500,60.0), "Three payments are insufficient");
        okTargets(!Night.meetsVictoryTargets(4,4499,60.0), "Revenue below $45 is insufficient");
        okTargets(!Night.meetsVictoryTargets(4,4500,59.99), "Paid average below 60 is insufficient");
        okTargets(!Night.meetsVictoryTargets(4,4500,Double.NaN), "No paid satisfaction does not imply victory");
    }

    private static void okTargets(boolean result, String message) {
        checks++;
        if (!result) throw new AssertionError(message);
    }

    public static void main(String[] args) {
        victoryRequiresAllThreeTargets();
        polymorphism(); arrivalsAndFlow(); stage2Victory(); invalidsRemainAtomic();
        System.out.println("PASS Stage 2 checks: "+checks);
    }
}

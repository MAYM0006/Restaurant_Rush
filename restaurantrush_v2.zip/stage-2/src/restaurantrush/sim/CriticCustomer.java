package restaurantrush.sim;

import java.util.Comparator;

/** Critic loses 12 satisfaction/turn and independently favours long-preparation food. */
public final class CriticCustomer extends Guest {
    public CriticCustomer(String name) { super(name); }
    @Override public int decayRate() { return 12; }
    @Override public String kind() { return "Critic"; }
    @Override public Dish chooseFood(FoodMenu menu, int ordinal) {
        return menu.dishes().stream().max(Comparator.comparingInt(d -> d.prepUnits)).orElseThrow();
    }
}

package restaurantrush.sim;

import java.util.Scanner;

/** Runnable offline command-line entry point. Input may be piped from a demo transcript. */
public final class DinerMain {
    private DinerMain() {}
    public static void main(String[] args) {
        Night night = Night.opening();
        Scanner scanner = new Scanner(System.in);
        System.out.println("Restaurant Rush - Stage 2 | 18 turns | two tables");
        System.out.println("Example actions: seat Ari 1 | wait   ;   order Ari | prep Ari   ;   serve Ari | wait");
        while (night.currentTurn() < Night.TURN_COUNT) {
            night.startTurn();
            for (String event : night.events()) System.out.println(event);
            System.out.print(night.report());
            printCommandHelp();
            while (night.awaitingActions()) {
                System.out.print("Waiter | Chef > ");
                if (!scanner.hasNextLine()) {
                    System.out.println("Input ended before the 18-turn game was complete.");
                    return;
                }
                try {
                    Diner.Choice actions = Diner.parse(scanner.nextLine());
                    night.act(actions.waiter(), actions.chef());
                } catch (IllegalArgumentException | IllegalStateException ex) {
                    System.out.println("Invalid choice: " + ex.getMessage() + " Retry; this turn has not been consumed.");
                }
            }
            for (String line : night.events()) System.out.println(line);
            System.out.println("End of turn " + night.currentTurn() + ".\n");
        }
        System.out.print(night.report());
        System.out.println("FINAL RESULT: " + (night.victory() ? "VICTORY" : "DEFEAT"));
    }

    /** Repeat the complete input format each turn, just before asking for actions. */
    private static void printCommandHelp() {
        System.out.println("Available commands (one action per staff member; separate with |):");
        System.out.println("  WAITER: seat NAME TABLE (1 or 2), order NAME, serve NAME, wait");
        System.out.println("  CHEF:   prep NAME, wait");
        System.out.println("  Format: WAITER | CHEF");
        System.out.println("  Example: seat Ari 1 | wait");
        System.out.println("  Example: order Ari | prep Ari");
        System.out.println("  No actions: wait | wait");
    }
}

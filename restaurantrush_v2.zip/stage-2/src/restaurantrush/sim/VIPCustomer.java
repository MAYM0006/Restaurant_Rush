package restaurantrush.sim;

import java.util.Comparator;

/** VIP loses 5 satisfaction/turn and receives 10% off the original price. */
public final class VIPCustomer extends Guest {
    public VIPCustomer(String name) { super(name); }
    @Override public int decayRate() { return 5; }
    @Override public String kind() { return "VIP"; }
    @Override public int priceKeepPercent() { return 90; }
    @Override public Dish chooseFood(FoodMenu menu, int ordinal) {
        return menu.dishes().stream().max(Comparator.comparingInt(d -> d.priceCents)).orElseThrow();
    }
}

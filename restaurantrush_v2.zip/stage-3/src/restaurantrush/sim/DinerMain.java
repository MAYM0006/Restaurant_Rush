package restaurantrush.sim;

import java.util.Scanner;

/** Offline Stage 3 console game; scriptable via standard input. */
public final class DinerMain {
    private DinerMain() {}
    public static void main(String[] args) {
        Night night = Night.opening();
        Scanner scanner = new Scanner(System.in);
        System.out.println("Restaurant Rush - Stage 3 | Host + VIP/Critic + ComboMeal + Happy Hour");
        System.out.println("Happy Hour may be activated once; you will only be asked until you use it.");
        while (night.currentTurn() < Night.TURN_COUNT) {
            while (!night.awaitingActions()) {
                if (night.happyHourUsed()) {
                    // Happy Hour lasts exactly two turns; it cannot be activated again.
                    // Do not prompt after its single activation (even once expired).
                    night.startTurn(false);
                    break;
                }
                System.out.print("Activate Happy Hour at start of next turn? (on/off): ");
                if (!scanner.hasNextLine()) { System.out.println("Input ended early."); return; }
                String requested = scanner.nextLine().trim();
                if (!requested.equalsIgnoreCase("on") && !requested.equalsIgnoreCase("off")) {
                    System.out.println("Please enter on or off."); continue;
                }
                try { night.startTurn(requested.equalsIgnoreCase("on")); }
                catch (IllegalArgumentException | IllegalStateException ex) {
                    System.out.println("Invalid activation: " + ex.getMessage());
                }
            }
            for (String event : night.events()) System.out.println(event);
            System.out.print(night.report());
            printCommandHelp();
            while (night.awaitingActions()) {
                System.out.print("Host | Waiter | Chef > ");
                if (!scanner.hasNextLine()) { System.out.println("Input ended early."); return; }
                try {
                    Diner.Choice choice = Diner.parse(scanner.nextLine());
                    night.act(choice.host(), choice.waiter(), choice.chef());
                } catch (IllegalArgumentException | IllegalStateException ex) {
                    System.out.println("Invalid choice: " + ex.getMessage() + " Retry without losing the turn.");
                }
            }
            for (String line : night.events()) System.out.println(line);
            System.out.println("End of turn " + night.currentTurn() + ".\n");
        }
        System.out.print(night.report());
        System.out.println("FINAL RESULT: " + (night.victory() ? "VICTORY" : "DEFEAT"));
    }

    /** Show the same complete input format before the player's actions each turn. */
    private static void printCommandHelp() {
        System.out.println("Available commands (one action per staff member; separate with |):");
        System.out.println("  HOST:   seat NAME TABLE (1 or 2), wait");
        System.out.println("  WAITER: seat NAME TABLE (1 or 2), order NAME, serve NAME, wait");
        System.out.println("  CHEF:   prep NAME, wait");
        System.out.println("  Format: HOST | WAITER | CHEF");
        System.out.println("  Example: seat Ari 1 | order Ari | prep Ari");
        System.out.println("  No actions: wait | wait | wait");
    }
}

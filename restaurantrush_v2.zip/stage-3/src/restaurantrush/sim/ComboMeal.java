package restaurantrush.sim;

import restaurantrush.entity.Money;

/** Stage 3 two-item combo: 90% combined price, sum of preparation units. */
public final class ComboMeal extends Dish {
    public final Dish first;
    public final Dish second;
    public ComboMeal(Dish first, Dish second) {
        super("combo-" + first.id + "-" + second.id, first.name + " + " + second.name + " Combo",
                Money.keepPercent(first.priceCents + second.priceCents, 90),
                first.prepUnits + second.prepUnits);
        this.first = first;
        this.second = second;
    }
}

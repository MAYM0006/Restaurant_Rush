package restaurantrush.sim;

import java.util.ArrayList;
import java.util.List;
import restaurantrush.entity.Money;

/** One discrete 18-turn shift. This replaces the prior elapsed-millisecond simulation. */
public final class Night {
    public static final int TURN_COUNT = 18;
    private final FoodMenu menu;
    private final List<Guest> customers = new ArrayList<>();
    private final List<Table> tables = List.of(new Table(1), new Table(2));
    private final List<String> events = new ArrayList<>();
    private int currentTurn;
    private int revenueCents;
    private int servedCount;
    private int unhappyDepartures;
    private int orderOrdinal;
    private boolean awaitingActions;
    private boolean happyHourUsed;
    private int happyHourTurnsRemaining;

    public Night(FoodMenu menu) { this.menu = menu; }
    public static Night opening() { return new Night(FoodMenu.stage3Opening()); }
    public boolean happyHourUsed() { return happyHourUsed; }
    public int happyHourTurnsRemaining() { return happyHourTurnsRemaining; }
    public int currentTurn() { return currentTurn; }
    public int revenueCents() { return revenueCents; }
    public int servedCount() { return servedCount; }
    public int unhappyDepartures() { return unhappyDepartures; }
    public List<Guest> customers() { return List.copyOf(customers); }
    public List<Table> tables() { return tables; }
    public List<String> events() { return List.copyOf(events); }
    public boolean awaitingActions() { return awaitingActions; }

    public int paidCount() {
        int result = 0;
        for (Guest c : customers) if (c.phase() == Guest.Phase.PAID) result++;
        return result;
    }

    public double averagePaidSatisfaction() {
        int total = 0;
        for (Guest c : customers) if (c.phase() == Guest.Phase.PAID) total += c.paidSatisfaction();
        return paidCount() == 0 ? Double.NaN : (double) total / paidCount();
    }

    /** Pure outcome rule, including the average paid-customer satisfaction threshold. */
    public static boolean meetsVictoryTargets(int paid, int revenueCents, double averagePaidSatisfaction) {
        return paid >= 4 && revenueCents >= 4500 && averagePaidSatisfaction >= 60.0;
    }

    public boolean victory() {
        return currentTurn == TURN_COUNT && !awaitingActions
            && meetsVictoryTargets(paidCount(), revenueCents, averagePaidSatisfaction());
    }

    /** Happy Hour is chosen BEFORE manager tasks and takes effect this turn and the next. */
    public void startTurn(boolean activateHappyHour) {
        if (awaitingActions) throw new IllegalStateException("Finish the current turn first.");
        if (currentTurn >= TURN_COUNT) throw new IllegalStateException("All 18 turns are complete.");
        if (activateHappyHour && happyHourUsed)
            throw new IllegalArgumentException("Happy Hour can be activated only once per game.");
        currentTurn++;
        awaitingActions = true;
        events.clear();
        if (activateHappyHour) {
            happyHourUsed = true;
            happyHourTurnsRemaining = 2;
            events.add("Happy Hour ACTIVATED for this turn and the next.");
        }
        for (Guest customer : Guests.arriving(currentTurn)) {
            customers.add(customer);
            events.add(customer.name() + " arrives (" + customer.kind() + ", satisfaction 100).");
        }
        if (happyHourTurnsRemaining > 0) {
            for (Guest customer : customers) customer.restore(15);
            events.add("Happy Hour: +15 satisfaction (maximum 100) for customers waiting for table or food.");
        }
    }

    /** Invalid actions are rejected before any game state is changed. */
    public void act(Host.Action host, Waiter.Action waiter, Chef.Action chef) {
        if (!awaitingActions) throw new IllegalStateException("Start a turn before choosing actions.");
        if (host == null || waiter == null || chef == null)
            throw new IllegalArgumentException("Host, Waiter and Chef choices are required.");
        validateHost(host);
        validateWaiter(waiter, host);
        validateChef(chef, waiter, host);
        performHost(host);
        performWaiter(waiter);
        performChef(chef);
        payOldestEligible();
        for (Guest customer : customers) customer.advanceEating(currentTurn);
        for (Guest customer : customers) {
            if (customer.decay()) {
                unhappyDepartures++;
                freeTable(customer);
                events.add(customer.name() + " abandoned at satisfaction 0; unfinished order cancelled, no revenue.");
            }
        }
        awaitingActions = false;
        if (happyHourTurnsRemaining > 0) happyHourTurnsRemaining--;
        if (currentTurn == TURN_COUNT)
            events.add(victory() ? "VICTORY" : "DEFEAT");
    }

    private Guest find(String name) {
        if (name == null) throw new IllegalArgumentException("Customer name required.");
        for (Guest c : customers) if (c.name().equalsIgnoreCase(name)) return c;
        throw new IllegalArgumentException("Customer not found: " + name);
    }

    private Table table(int number) {
        if (number < 1 || number > tables.size()) throw new IllegalArgumentException("Table must be 1 or 2.");
        return tables.get(number - 1);
    }

    private void validateHost(Host.Action host) {
        if (host.isWait()) return;
        Guest c = find(host.customer());
        if (c.phase() != Guest.Phase.WAITING)
            throw new IllegalArgumentException("Host can seat only a waiting customer.");
        if (table(host.table()).isOccupied()) throw new IllegalArgumentException("Host selected an occupied table.");
    }

    private void validateWaiter(Waiter.Action choice, Host.Action host) {
        switch (choice.task()) {
            case WAIT -> {}
            case SEAT -> {
                Guest c = find(choice.customer());
                if (c.phase() != Guest.Phase.WAITING) throw new IllegalArgumentException("Customer is not waiting.");
                if (table(choice.table()).isOccupied()) throw new IllegalArgumentException("Table is occupied.");
                if (!host.isWait() && (choice.table() == host.table()
                        || c.name().equalsIgnoreCase(host.customer())))
                    throw new IllegalArgumentException("Host and Waiter cannot seat in the same table or seat the same customer.");
            }
            case TAKE_ORDER -> {
                Guest c = find(choice.customer());
                boolean hostWillSeat = !host.isWait() && c.name().equalsIgnoreCase(host.customer())
                    && c.phase() == Guest.Phase.WAITING;
                if ((c.phase() != Guest.Phase.SEATED && !hostWillSeat) || c.order() != null)
                    throw new IllegalArgumentException("Customer must be seated (or being seated by Host) and not yet ordered.");
            }
            case SERVE -> {
                Guest c = find(choice.customer());
                if (c.phase() != Guest.Phase.SEATED || c.order() == null || !c.order().isReady())
                    throw new IllegalArgumentException("Customer must have a READY order from an earlier turn.");
            }
        }
    }

    private void validateChef(Chef.Action chef, Waiter.Action waiter, Host.Action host) {
        if (chef.isWait()) return;
        Guest c = find(chef.customer());
        boolean hostWillSeat = !host.isWait() && c.name().equalsIgnoreCase(host.customer())
            && c.phase() == Guest.Phase.WAITING;
        if (c.phase() != Guest.Phase.SEATED && !hostWillSeat)
            throw new IllegalArgumentException("Chef can prepare only a seated customer's order.");
        if (c.order() != null && c.order().orderStatus() == OrderStatus.PREPARING) return;
        if (c.order() == null && waiter.task() == Waiter.Task.TAKE_ORDER
                && c.name().equalsIgnoreCase(waiter.customer())) return;
        throw new IllegalArgumentException("Chef can prepare only an existing PREPARING order, or one taken this turn.");
    }

    private void performHost(Host.Action host) {
        if (host.isWait()) { events.add("Host waits."); return; }
        Guest c = find(host.customer());
        table(host.table()).assignCustomer(c);
        events.add("Host seats " + c.name() + " at Table " + host.table() + ".");
    }

    private void performWaiter(Waiter.Action waiter) {
        switch (waiter.task()) {
            case WAIT -> events.add("Waiter waits.");
            case SEAT -> {
                Guest c = find(waiter.customer());
                table(waiter.table()).assignCustomer(c);
                events.add("Waiter seats " + c.name() + " at Table " + waiter.table() + ".");
            }
            case TAKE_ORDER -> {
                Guest c = find(waiter.customer());
                Dish chosen = c.chooseFood(menu, orderOrdinal++);
                c.takeOrder(chosen, happyHourTurnsRemaining > 0);
                events.add("Waiter takes " + c.name() + "'s order: " + chosen.name
                    + ", " + Money.dollars(c.order().priceCents()) + ", " + chosen.prepUnits + " prep units.");
            }
            case SERVE -> {
                Guest c = find(waiter.customer());
                c.serve(currentTurn);
                servedCount++;
                events.add("Waiter serves " + c.name() + "; satisfaction freezes at " + c.satisfaction() + ".");
            }
        }
    }

    private void performChef(Chef.Action chef) {
        if (chef.isWait()) { events.add("Chef waits."); return; }
        Guest c = find(chef.customer());
        Order o = c.order();
        o.advancePrep();
        events.add("Chef prepares " + c.name() + "'s order: " + o.unitsDone() + "/"
            + o.requiredUnits() + (o.isReady() ? " (READY for a later turn)." : "."));
    }

    private void payOldestEligible() {
        Guest c = Cashier.oldestEligible(customers, currentTurn);
        if (c == null) return;
        c.pay(currentTurn);
        revenueCents += c.order().priceCents();
        freeTable(c);
        events.add("Cashier collects " + Money.dollars(c.order().priceCents()) + " from "
            + c.name() + " (satisfaction " + c.paidSatisfaction() + ").");
    }

    private void freeTable(Guest c) {
        for (Table t : tables) if (t.occupant() == c) t.clear();
    }

    public String report() {
        StringBuilder s = new StringBuilder();
        s.append("Turn ").append(currentTurn).append("/18 | Revenue ").append(Money.dollars(revenueCents))
            .append(" | Paid ").append(paidCount()).append(" | Avg paid satisfaction ");
        s.append(paidCount() == 0 ? "N/A" : String.format(java.util.Locale.ROOT, "%.1f", averagePaidSatisfaction()));
        s.append(" | Served ").append(servedCount).append(" | Unhappy departures ").append(unhappyDepartures).append('\n');
        s.append("Waiting queue: ");
        boolean any = false;
        for (Guest c : customers) if (c.phase() == Guest.Phase.WAITING) {
            if (any) s.append(", ");
            s.append(c.name()); any = true;
        }
        if (!any) s.append("(empty)");
        s.append('\n');
        for (Table t : tables) s.append("Table ").append(t.number()).append(": ")
            .append(t.occupant() == null ? "free" : t.occupant().name()).append('\n');
        for (Guest c : customers) {
            s.append(c.name()).append(" [").append(c.kind()).append("] ")
                .append(c.phase()).append(" satisfaction=").append(c.satisfaction());
            if (c.order() != null) s.append(" order=").append(c.order().orderStatus())
                .append(" ").append(c.order().unitsDone()).append("/").append(c.order().requiredUnits());
            s.append('\n');
        }
        s.append("Staff available: Host (1 seat), Waiter (1 action), Chef (1 prep unit), Cashier (automatic 1 payment).\n");
        s.append("Happy Hour remaining turns: ").append(happyHourTurnsRemaining)
            .append(" | already activated: ").append(happyHourUsed).append('\n');
        return s.toString();
    }
}

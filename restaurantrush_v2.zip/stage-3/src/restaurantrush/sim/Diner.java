package restaurantrush.sim;

import java.util.Locale;

/** Stage 3 CLI: interface only, all rule enforcement remains in domain classes. */
public final class Diner {
    private Diner() {}
    public record Choice(Host.Action host, Waiter.Action waiter, Chef.Action chef) {}

    /** Format "host-action | waiter-action | chef-action", e.g. "seat Ari 1 | order Ari | prep Ari". */
    public static Choice parse(String input) {
        String[] parts = input == null ? new String[0] : input.trim().split("\\|", -1);
        if (parts.length != 3)
            throw new IllegalArgumentException("Use HOST | WAITER | CHEF (e.g. wait | order Ari | prep Ari).");
        return new Choice(host(parts[0]), waiter(parts[1]), chef(parts[2]));
    }

    private static Host.Action host(String input) {
        String[] tokens = input.trim().split("\\s+");
        if (tokens.length == 1 && tokens[0].equalsIgnoreCase("wait")) return Host.Action.waitAction();
        if (tokens.length == 3 && tokens[0].equalsIgnoreCase("seat")) {
            try { return Host.Action.seat(tokens[1], Integer.parseInt(tokens[2])); }
            catch (NumberFormatException ignored) { }
        }
        throw new IllegalArgumentException("Host action: wait or seat NAME TABLE.");
    }

    private static Waiter.Action waiter(String input) {
        String[] tokens = input.trim().split("\\s+");
        String action = tokens[0].toLowerCase(Locale.ROOT);
        switch (action) {
            case "wait" -> { if (tokens.length == 1) return Waiter.Action.waitAction(); }
            case "seat" -> {
                if (tokens.length == 3) {
                    try { return Waiter.Action.seat(tokens[1], Integer.parseInt(tokens[2])); }
                    catch (NumberFormatException ignored) { }
                }
            }
            case "order" -> { if (tokens.length == 2) return Waiter.Action.order(tokens[1]); }
            case "serve" -> { if (tokens.length == 2) return Waiter.Action.serve(tokens[1]); }
            default -> { }
        }
        throw new IllegalArgumentException("Waiter action: wait, seat NAME TABLE, order NAME, or serve NAME.");
    }

    private static Chef.Action chef(String input) {
        String[] tokens = input.trim().split("\\s+");
        if (tokens.length == 1 && tokens[0].equalsIgnoreCase("wait")) return Chef.Action.waitAction();
        if (tokens.length == 2 && tokens[0].equalsIgnoreCase("prep")) return Chef.Action.prepare(tokens[1]);
        throw new IllegalArgumentException("Chef action: wait or prep NAME.");
    }
}

package restaurantrush.sim;

/** Stage 3 Host seats up to one additional customer independently of the Waiter. */
public final class Host {
    public record Action(String customer, int table) {
        public static Action waitAction() { return new Action("", 0); }
        public static Action seat(String name, int table) { return new Action(name, table); }
        public boolean isWait() { return customer == null || customer.isEmpty(); }
    }
    private Host() {}
}

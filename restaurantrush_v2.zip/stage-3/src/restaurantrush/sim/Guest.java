package restaurantrush.sim;

/** Customer object owns satisfaction, order choice and lifecycle transitions. */
public abstract class Guest {
    public enum Phase { WAITING, SEATED, SERVED, EATING, READY_TO_PAY, PAID, LEFT }

    private final String name;
    private int satisfaction = 100;
    private Phase phase = Phase.WAITING;
    private int tableNumber = -1;
    private Order order;
    private int servedTurn = -1;
    private int readyTurn = -1;
    private int paidSatisfaction = -1;

    protected Guest(String name) { this.name = name; }
    public String name() { return name; }
    public Phase phase() { return phase; }
    public int satisfaction() { return satisfaction; }
    public int tableNumber() { return tableNumber; }
    public Order order() { return order; }
    public int paidSatisfaction() { return paidSatisfaction; }
    public int readyTurn() { return readyTurn; }
    public abstract int decayRate();
    public abstract String kind();
    public abstract Dish chooseFood(FoodMenu menu, int orderNumber);
    public int priceKeepPercent() { return 100; }

    public void seat(int number) {
        require(Phase.WAITING);
        if (number < 1) throw new IllegalArgumentException("Invalid table number.");
        tableNumber = number;
        phase = Phase.SEATED;
    }

    public void takeOrder(Dish dish, boolean happyHour) {
        require(Phase.SEATED);
        if (order != null) throw new IllegalStateException("Customer has already ordered.");
        order = new Order(dish, priceKeepPercent(), happyHour);
    }

    public void serve(int turn) {
        require(Phase.SEATED);
        if (order == null || !order.isReady()) throw new IllegalStateException("Order is not READY.");
        order.serve();
        servedTurn = turn;
        phase = Phase.SERVED;
    }

    /** Eating requires the entire turn AFTER service; cannot pay until next turn. */
    public void advanceEating(int turn) {
        if (phase == Phase.SERVED && servedTurn < turn) {
            phase = Phase.EATING;
            phase = Phase.READY_TO_PAY;
            readyTurn = turn;
        }
    }

    public void pay(int turn) {
        require(Phase.READY_TO_PAY);
        if (readyTurn >= turn) throw new IllegalStateException("Payment requires a later turn.");
        order.pay();
        paidSatisfaction = satisfaction;
        phase = Phase.PAID;
        tableNumber = -1;
    }

    /** Returns true when this customer abandons this turn. */
    public boolean decay() {
        if (phase != Phase.WAITING && phase != Phase.SEATED) return false;
        satisfaction = Math.max(0, satisfaction - decayRate());
        if (satisfaction != 0) return false;
        phase = Phase.LEFT;
        if (order != null && (order.orderStatus() == OrderStatus.PREPARING
                || order.orderStatus() == OrderStatus.READY)) order.cancel();
        tableNumber = -1;
        return true;
    }

    /** Active Happy Hour heals only customers waiting for seating or food. */
    public void restore(int points) {
        if (phase == Phase.WAITING || phase == Phase.SEATED)
            satisfaction = Math.min(100, satisfaction + points);
    }

    private void require(Phase wanted) {
        if (phase != wanted) throw new IllegalStateException(
            name + " must be " + wanted + ", but is " + phase + ".");
    }
}

package restaurantrush.sim;

/** Standalone Stage 3 regression tests with no external testing libraries. */
public final class StageTests {
    private static int checks;
    private static void ok(boolean b, String name) { checks++; if (!b) throw new AssertionError(name); }
    private static Guest find(Night n, String name) {
        return n.customers().stream().filter(x -> x.name().equals(name)).findFirst().orElseThrow();
    }
    private static void run(Night n, boolean happy, Host.Action host, Waiter.Action waiter, Chef.Action chef) {
        n.startTurn(happy); n.act(host,waiter,chef);
    }
    private static void waitTurn(Night n) { run(n,false,Host.Action.waitAction(),Waiter.Action.waitAction(),Chef.Action.waitAction()); }

    private static void comboMealAndPriceOrder() {
        FoodMenu menu=FoodMenu.stage3Opening();
        ok(menu.dishes().size()==4,"Three base dishes and a ComboMeal");
        Dish combo=menu.dishes().get(3);
        ok(combo instanceof ComboMeal,"ComboMeal is a type of Dish");
        ok(combo.priceCents==2430 && combo.prepUnits==3,"Salad + Pasta is $24.30 with 3 prep units");
        ok(new Order(new Dish("burger","Burger",1500,1),90,true).priceCents()==1080,
            "VIP first, then Happy Hour: $10.80");
        ok(new Order(combo,90,false).priceCents()==2187,"VIP ComboMeal 10% discount");
        ok(new VIPCustomer("VIP").chooseFood(menu,0)==combo,"VIP picks most expensive item");
        ok(new CriticCustomer("Critic").chooseFood(menu,0)==combo,"Critic picks longest-prep item");
    }

    private static void hostAndAtomicValidation() {
        Night n=Night.opening(); n.startTurn(false);
        boolean rejected=false;
        try { n.act(Host.Action.seat("Ari",1),Waiter.Action.seat("Ari",1),Chef.Action.waitAction()); }
        catch(IllegalArgumentException e){ rejected=true; }
        ok(rejected && n.awaitingActions() && n.currentTurn()==1,"Host/Waiter conflict is rejected atomically");
        ok(!n.tables().get(0).isOccupied(),"Rejected move did not occupy table");
        n.act(Host.Action.seat("Ari",1),Waiter.Action.order("Ari"),Chef.Action.prepare("Ari"));
        ok(find(n,"Ari").order().isReady(),"Host seats, Waiter takes order, Chef cooks in same turn");
        ok(find(n,"Ari").satisfaction()==92,"Waiting satisfaction decay applies");
        ok(n.servedCount()==0 && n.paidCount()==0,"Preparation does not imply serving or payment");
    }

    private static void happyHourRecoveryDurationAndLock() {
        Night n=Night.opening();
        run(n,true,Host.Action.seat("Ari",1),Waiter.Action.order("Ari"),Chef.Action.prepare("Ari"));
        Guest ari=find(n,"Ari");
        ok(ari.order().priceCents()==720,"Salad ordered in Happy Hour has 20% off");
        ok(n.happyHourUsed() && n.happyHourTurnsRemaining()==1,"Duration after first active turn");
        run(n,false,Host.Action.waitAction(),Waiter.Action.serve("Ari"),Chef.Action.waitAction());
        ok(ari.satisfaction()==100,"+15 turn-start restoration capped at 100");
        ok(n.happyHourTurnsRemaining()==0,"Happy Hour lasts exactly two turns");
        waitTurn(n); // T3: customer becomes READY_TO_PAY
        ok(ari.phase()==Guest.Phase.READY_TO_PAY && n.paidCount()==0,"Not paid on eating turn");
        run(n,false,Host.Action.seat("Blair",2),Waiter.Action.order("Blair"),Chef.Action.prepare("Blair"));
        ok(ari.phase()==Guest.Phase.PAID && n.revenueCents()==720,"Price stays locked through payment");
        ok(find(n,"Blair").order().priceCents()==2187,"VIP combo ordered after Happy Hour has no 20% discount");
        boolean rejected=false;
        try { n.startTurn(true); } catch(IllegalArgumentException e) { rejected=true; }
        ok(rejected && n.currentTurn()==4 && !n.awaitingActions(),"Second Happy Hour activation rejected before advancing turn");
    }

    private static void stage3VictoryAndDefeat() {
        Night n=Night.opening();
        String[] rows={
            "off;seat Ari 1 | order Ari | prep Ari",
            "off;wait | serve Ari | wait",
            "off;wait | wait | wait",
            "on;seat Blair 2 | order Blair | prep Blair",
            "off;wait | wait | prep Blair",
            "off;wait | wait | prep Blair",
            "off;seat Chen 1 | serve Blair | wait",
            "off;wait | order Chen | prep Chen",
            "off;wait | wait | prep Chen",
            "off;seat Dina 2 | serve Chen | wait",
            "off;wait | order Dina | prep Dina",
            "off;wait | wait | prep Dina",
            "off;wait | wait | prep Dina",
            "off;wait | serve Dina | wait",
            "off;wait | wait | wait",
            "off;wait | wait | wait",
            "off;wait | wait | wait",
            "off;wait | wait | wait"
        };
        for(String row:rows) {
            String[] parts=row.split(";",2);
            Diner.Choice choice=Diner.parse(parts[1]);
            run(n,parts[0].equals("on"),choice.host(),choice.waiter(),choice.chef());
        }
        ok(n.currentTurn()==18 && n.paidCount()==4,"Four paid over full eighteen turns");
        ok(n.revenueCents()>=4500 && n.averagePaidSatisfaction()>=60 && n.victory(),
            "Stage 3 victory passes all three conditions");
        ok(find(n,"Farah").phase()!=Guest.Phase.PAID,"Turn-16 arrival cannot pay");
        Night defeat=Night.opening(); for(int i=0;i<18;i++) waitTurn(defeat);
        ok(!defeat.victory() && defeat.paidCount()==0,"Defeat trace works");
    }

    private static void lateArrivalCannotPay() {
        Night n=Night.opening(); for(int i=0;i<15;i++) waitTurn(n);
        run(n,false,Host.Action.seat("Farah",1),Waiter.Action.order("Farah"),Chef.Action.prepare("Farah"));
        ok(find(n,"Farah").order().isReady(),"One-unit dish ready T16");
        run(n,false,Host.Action.waitAction(),Waiter.Action.serve("Farah"),Chef.Action.waitAction());
        waitTurn(n); // T18: eating finishes, not payment
        ok(find(n,"Farah").phase()==Guest.Phase.READY_TO_PAY && n.paidCount()==0,
            "Late arrival cannot pay on turn 18");
    }

    private static void victoryRequiresAllThreeTargets() {
        okTargets(Night.meetsVictoryTargets(4,4500,60.0), "All victory thresholds satisfied");
        okTargets(!Night.meetsVictoryTargets(3,4500,60.0), "Three payments are insufficient");
        okTargets(!Night.meetsVictoryTargets(4,4499,60.0), "Revenue below $45 is insufficient");
        okTargets(!Night.meetsVictoryTargets(4,4500,59.99), "Paid average below 60 is insufficient");
        okTargets(!Night.meetsVictoryTargets(4,4500,Double.NaN), "No paid satisfaction does not imply victory");
    }

    private static void okTargets(boolean result, String message) {
        checks++;
        if (!result) throw new AssertionError(message);
    }

    public static void main(String[] args) {
        victoryRequiresAllThreeTargets();
        comboMealAndPriceOrder(); hostAndAtomicValidation();
        happyHourRecoveryDurationAndLock(); stage3VictoryAndDefeat(); lateArrivalCannotPay();
        System.out.println("PASS Stage 3 checks: " + checks);
    }
}
